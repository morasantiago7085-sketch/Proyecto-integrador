import { useState } from 'react'
import {
  Building2, CalendarDays, CalendarPlus, Check, CheckCircle2, Clock3, Pencil, Plus, RotateCcw, Tags, Trash2, UserPlus, UsersRound, X,
} from 'lucide-react'
import { formatDate, getName, todayString } from '../../core/utils/formatters.js'
import { makeId } from '../../core/utils/ids.js'
import { Avatar, ModalShell, StatusBadge } from '../../core/design-system/UI.jsx'
import { useData } from '../../core/states/DataContext.jsx'
import { useAuth } from '../../auth/states/AuthContext.jsx'
import { can } from '../../auth/lib/permissions.js'

export default function ChallengeDetailModal({ item, data, onClose, openEdit, openCreate }) {
  const { user } = useAuth()
  const { saveRecord, removeRecord } = useData()
  const [newMember, setNewMember] = useState('')
  const [confirmClose, setConfirmClose] = useState(false)
  const [busy, setBusy] = useState(false)
  const [eventForm, setEventForm] = useState({ id: '', nombre: '', fecha: '' })
  const [eventError, setEventError] = useState('')

  const company = data.empresas.find(empresa => empresa.id === item.empresaId)
  const registrations = data.registros.filter(registration => registration.retoId === item.id)
  const memberIds = new Set(registrations.map(registration => registration.usuarioId))
  const candidates = data.usuarios.filter(person => person.estado === 'Activo' && !memberIds.has(person.id))
  const isClosed = item.estado === 'Cerrado'

  const canUpdate = can(user, 'update', 'retos')
  const manageMembers = user.rol !== 'Participante' && can(user, 'create', 'registros')
  const canRemoveMembers = can(user, 'delete', 'registros')

  const run = async action => { setBusy(true); try { await action() } finally { setBusy(false) } }
  const updateReto = changes => saveRecord('retos', { ...item, ...changes }, true)

  const addMember = () => run(async () => {
    if (!newMember) return
    const ok = await saveRecord('registros', {
      id: makeId(), usuarioId: newMember, retoId: item.id, fechaRegistro: todayString(),
      estado: 'Aprobado', observacion: 'Agregado como integrante del reto.',
    }, false)
    if (ok) setNewMember('')
  })

  // Eventos / hitos del reto (reuniones, entregas...), editables por quien puede modificar retos.
  const events = [...(item.eventos ?? [])].sort((a, b) => a.fecha.localeCompare(b.fecha))
  const resetEvent = () => { setEventForm({ id: '', nombre: '', fecha: '' }); setEventError('') }
  const saveEvent = () => run(async () => {
    const nombre = eventForm.nombre.trim()
    if (!nombre || !eventForm.fecha) return setEventError('Escribe el nombre y la fecha del evento.')
    const next = eventForm.id
      ? events.map(event => event.id === eventForm.id ? { ...event, nombre, fecha: eventForm.fecha } : event)
      : [...events, { id: makeId(), nombre, fecha: eventForm.fecha }]
    if (await updateReto({ eventos: next })) resetEvent()
  })
  const removeEvent = id => run(() => updateReto({ eventos: events.filter(event => event.id !== id) }))

  const finish = () => run(async () => {
    const today = todayString()
    await updateReto({ estado: 'Cerrado', fechaFin: item.fechaFin > today ? today : item.fechaFin })
    setConfirmClose(false)
  })

  return <ModalShell onClose={onClose} size="detail">
    <div className="modal-header detail-header"><div><div className="eyebrow">DETALLE DEL RETO</div><h2>{item.nombre}</h2><p>Presentado por {company?.nombre || 'Empresa no disponible'}</p></div><button className="modal-x" onClick={onClose} aria-label="Cerrar"><X size={21}/></button></div>
    <div className="detail-body">
      <div className="detail-badges"><StatusBadge value={item.estado}/><StatusBadge priority value={getName(data, 'prioridades', item.prioridadId)}/><span className="detail-category"><Tags size={15}/>{getName(data, 'categorias', item.categoriaId)}</span></div>
      <div className="detail-section"><h3>Acerca del desafío</h3><p>{item.descripcion}</p></div>
      <div className="detail-facts">
        <div><CalendarDays size={20}/><span><small>Fecha de inicio</small><strong>{formatDate(item.fechaInicio)}</strong></span></div>
        <div><Clock3 size={20}/><span><small>Fecha de finalización</small><strong>{formatDate(item.fechaFin)}</strong></span></div>
        <div><Building2 size={20}/><span><small>Empresa</small><strong>{company?.nombre || '—'}</strong></span></div>
        <div><UsersRound size={20}/><span><small>Integrantes</small><strong>{registrations.length} inscrito{registrations.length === 1 ? '' : 's'}</strong></span></div>
      </div>

      {canUpdate && <div className="detail-section detail-controls">
        <h3>Gestión del reto</h3>
        <label className="inline-field"><span>Prioridad</span>
          <select value={item.prioridadId} disabled={busy} onChange={event => run(() => updateReto({ prioridadId: event.target.value }))}>
            {data.prioridades.map(priority => <option key={priority.id} value={priority.id}>{priority.nombre}</option>)}
          </select>
        </label>
        {isClosed
          ? <button className="btn btn-outline btn-small" disabled={busy} onClick={() => run(() => updateReto({ estado: 'Abierto' }))}><RotateCcw size={16}/> Reabrir reto</button>
          : confirmClose
            ? <span className="confirm-inline">¿Dar por terminado este reto?
              <button className="btn btn-primary btn-small" disabled={busy} onClick={finish}><CheckCircle2 size={16}/> Sí, finalizar</button>
              <button className="btn btn-outline btn-small" onClick={() => setConfirmClose(false)}>No</button></span>
            : <button className="btn btn-outline btn-small" disabled={busy} onClick={() => setConfirmClose(true)}><CheckCircle2 size={16}/> Finalizar reto</button>}
      </div>}

      <div className="detail-section detail-events">
        <h3>Eventos del reto <span>{events.length}</span></h3>
        {events.length
          ? events.map(event => <div key={event.id} className="event-row">
            <CalendarDays size={16}/><strong>{event.nombre}</strong><small>{formatDate(event.fecha)}</small>
            {canUpdate && <>
              <button className="action-button" title="Editar evento" aria-label={`Editar ${event.nombre}`} onClick={() => { setEventForm(event); setEventError('') }}><Pencil size={15}/></button>
              <button className="action-button danger" title="Eliminar evento" aria-label={`Eliminar ${event.nombre}`} disabled={busy} onClick={() => removeEvent(event.id)}><Trash2 size={15}/></button>
            </>}
          </div>)
          : <p>Aún no hay eventos programados.</p>}
        {canUpdate && <div className="event-form">
          <input value={eventForm.nombre} placeholder="Nombre del evento (ej. Entrega de propuestas)" aria-label="Nombre del evento" onChange={event => { setEventForm(form => ({ ...form, nombre: event.target.value })); setEventError('') }}/>
          <input type="date" value={eventForm.fecha} aria-label="Fecha del evento" onChange={event => { setEventForm(form => ({ ...form, fecha: event.target.value })); setEventError('') }}/>
          <button className="btn btn-primary btn-small" disabled={busy} onClick={saveEvent}>{eventForm.id ? <><Check size={16}/> Guardar</> : <><CalendarPlus size={16}/> Agregar</>}</button>
          {eventForm.id && <button className="btn btn-outline btn-small" onClick={resetEvent}>Cancelar</button>}
        </div>}
        {eventError && <div className="form-error" role="alert">{eventError}</div>}
      </div>

      <div className="detail-section detail-participants">
        <h3>Integrantes <span>{registrations.length}</span></h3>
        {manageMembers && !isClosed && <div className="member-add">
          <select value={newMember} onChange={event => setNewMember(event.target.value)} aria-label="Agregar integrante" disabled={busy}>
            <option value="">{candidates.length ? 'Selecciona una persona…' : 'No hay más usuarios activos'}</option>
            {candidates.map(person => <option key={person.id} value={person.id}>{person.nombre} · {person.cargo}</option>)}
          </select>
          <button className="btn btn-primary btn-small" disabled={!newMember || busy} onClick={addMember}><UserPlus size={16}/> Agregar</button>
        </div>}
        {registrations.length
          ? registrations.map((registration, index) => {
            const person = data.usuarios.find(row => row.id === registration.usuarioId)
            return <div key={registration.id} className="participant-row">
              <Avatar name={person?.nombre} index={index} size="small"/>
              <strong>{person?.nombre ?? 'No encontrado'}<small className="member-role">{person?.cargo}</small></strong>
              <StatusBadge value={registration.estado}/>
              {canRemoveMembers && <button className="action-button danger" title="Quitar del reto" aria-label={`Quitar a ${person?.nombre}`} disabled={busy} onClick={() => run(() => removeRecord('registros', registration.id))}><Trash2 size={15}/></button>}
            </div>
          })
          : <p>Aún no hay integrantes en este desafío.</p>}
      </div>
    </div>
    <div className="modal-footer">
      {canUpdate && <button className="btn btn-outline" onClick={() => openEdit('retos', item)}><Pencil size={17}/> Editar reto</button>}
      {can(user, 'create', 'registros') && !isClosed && (user.rol === 'Participante'
        ? !memberIds.has(user.id) && <button className="btn btn-primary" onClick={() => openCreate('registros', { retoId: item.id, usuarioId: user.id })}><Plus size={17}/> Inscribirme</button>
        : null)}
    </div>
  </ModalShell>
}
