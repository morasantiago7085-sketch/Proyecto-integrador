package com.integrador.backend.modelos;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "retos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Reto {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @JdbcTypeCode(SqlTypes.CHAR)
    @Column(name = "id", length = 36, nullable = false, updatable = false)
    private UUID id;

    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 200, message = "El nombre no puede superar 200 caracteres")
    @Column(length = 200, nullable = false)
    private String nombre;

    @NotBlank(message = "La descripción es obligatoria")
    @Size(max = 1000, message = "La descripción no puede superar 1000 caracteres")
    @Column(length = 1000, nullable = false)
    private String descripcion;

    @NotNull(message = "La empresa es obligatoria")
    @JdbcTypeCode(SqlTypes.CHAR)
    @Column(name = "empresa_id", length = 36, nullable = false)
    private UUID empresaId;

    @NotNull(message = "La categoría es obligatoria")
    @JdbcTypeCode(SqlTypes.CHAR)
    @Column(name = "categoria_id", length = 36, nullable = false)
    private UUID categoriaId;

    @NotNull(message = "La prioridad es obligatoria")
    @JdbcTypeCode(SqlTypes.CHAR)
    @Column(name = "prioridad_id", length = 36, nullable = false)
    private UUID prioridadId;

    // Valores que usa el frontend: "Abierto", "En revisión", "Cerrado"
    @NotBlank(message = "El estado es obligatorio")
    @Column(nullable = false)
    private String estado;

    @NotNull(message = "La fecha de inicio es obligatoria")
    @Column(name = "fecha_inicio", nullable = false)
    private LocalDate fechaInicio;

    @NotNull(message = "La fecha de cierre es obligatoria")
    @Column(name = "fecha_fin", nullable = false)
    private LocalDate fechaFin;
}
