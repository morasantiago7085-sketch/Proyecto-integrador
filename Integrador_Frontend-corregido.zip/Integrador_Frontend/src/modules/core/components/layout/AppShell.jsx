import { useEffect, useRef, useState } from 'react'
import { ChevronRight, Menu, Search } from 'lucide-react'
import { navItems } from '../../lib/registry.js'
import { API_MODE } from '../../services/api.js'
import { Avatar } from '../../design-system/UI.jsx'
import { useAuth } from '../../../auth/states/AuthContext.jsx'
import { useData } from '../../states/DataContext.jsx'
import { useUI } from '../../states/UIContext.jsx'
import Sidebar from './Sidebar.jsx'

export default function AppShell({ page, navigate, children }) {
  const { user } = useAuth()
  const { loading, error } = useData()
  const { searches, setSearch } = useUI()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const searchRef = useRef(null)
  const activeItem = navItems.find(nav => nav.id === page)

  useEffect(() => {
    const handler = event => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault()
        if (page !== 'retos') navigate('retos')
        setTimeout(() => searchRef.current?.focus(), 60)
      }
    }
    document.addEventListener('keydown', handler)
    return () => document.removeEventListener('keydown', handler)
  }, [page, navigate])

  const status = loading ? 'CONECTANDO' : error ? 'SIN API' : API_MODE === 'http' ? 'API' : 'MODO LOCAL'

  return <div className="app-shell">
    <Sidebar active={page} onNavigate={navigate} open={sidebarOpen} onClose={() => setSidebarOpen(false)}/>
    <div className="main-area">
      <header className="topbar">
        <div className="topbar-left"><button className="mobile-menu icon-only" onClick={() => setSidebarOpen(true)} aria-label="Abrir menú"><Menu size={22}/></button><span className="topbar-location"><span>Workspace</span><ChevronRight size={14}/><strong>{activeItem?.label || 'Sobre el proyecto'}</strong></span></div>
        <div className="topbar-right">
          <label className="topbar-search"><Search size={18}/><input ref={searchRef} aria-label="Buscar retos globalmente" value={searches.retos ?? ''} onFocus={() => { if (page !== 'retos') navigate('retos') }} onChange={event => { setSearch('retos', event.target.value); if (page !== 'retos') navigate('retos') }} placeholder="Buscar retos..."/><kbd>⌘ K</kbd></label>
          <span className="topbar-divider"/>
          <span className="demo-pill"><span/>{status}</span>
          <Avatar name={user.nombre} index={4}/>
        </div>
      </header>
      <main id="contenido">{children}</main>
      <footer className="app-footer"><span>© {new Date().getFullYear()} Nexo · Plataforma de retos empresariales</span><span>{API_MODE === 'http' ? 'API REST • Node.js + MySQL' : 'Datos de demostración en este navegador'}</span></footer>
    </div>
  </div>
}
