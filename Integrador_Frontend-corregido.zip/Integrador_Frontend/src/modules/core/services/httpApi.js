// Cliente de la API REST (backend Node/Express + MySQL). Misma interfaz que mockApi.js.
import { request } from '../lib/http.js'

export const httpApi = {
  getData: () => request('/data'),
  create: (type, row) => request(`/${type}`, { method: 'POST', body: row }),
  update: (type, id, row) => request(`/${type}/${id}`, { method: 'PUT', body: row }),
  remove: (type, id) => request(`/${type}/${id}`, { method: 'DELETE' }),
  login: body => request('/auth/login', { method: 'POST', body }),
  register: body => request('/auth/register', { method: 'POST', body }),
  me: () => request('/auth/me'),
}
