export const isEmail = value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value).trim())

export function validateRegister({ nombre, correo, cargo, password, confirm }) {
  if (!String(nombre).trim()) return 'Ingresa tu nombre completo.'
  if (!isEmail(correo)) return 'Ingresa un correo electrónico válido.'
  if (!cargo) return 'Selecciona tu cargo.'
  if (String(password).length < 8) return 'La contraseña debe tener al menos 8 caracteres.'
  if (password !== confirm) return 'Las contraseñas no coinciden.'
  return ''
}
