package com.integrador.backend.controladores;

import com.integrador.backend.servicios.ServicioCategoria;
import com.integrador.backend.servicios.ServicioEmpresa;
import com.integrador.backend.servicios.ServicioPrioridad;
import com.integrador.backend.servicios.ServicioRegistro;
import com.integrador.backend.servicios.ServicioReto;
import com.integrador.backend.servicios.ServicioUsuario;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * El frontend carga todo de una vez con GET /api/data: un objeto con las seis listas.
 * Las claves deben llamarse igual que las entidades del frontend.
 */
@RestController
@RequestMapping("/api/data")
@RequiredArgsConstructor
public class ControladorData {

    private final ServicioEmpresa empresas;
    private final ServicioReto retos;
    private final ServicioCategoria categorias;
    private final ServicioPrioridad prioridades;
    private final ServicioUsuario usuarios;
    private final ServicioRegistro registros;

    @GetMapping
    public Map<String, Object> todo() {
        Map<String, Object> datos = new LinkedHashMap<>();
        datos.put("empresas", empresas.listar());
        datos.put("retos", retos.listar());
        datos.put("categorias", categorias.listar());
        datos.put("prioridades", prioridades.listar());
        datos.put("usuarios", usuarios.listar());
        datos.put("registros", registros.listar());
        return datos;
    }
}
