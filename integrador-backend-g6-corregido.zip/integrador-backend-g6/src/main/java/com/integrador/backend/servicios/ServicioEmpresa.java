package com.integrador.backend.servicios;

import com.integrador.backend.modelos.Empresa;
import com.integrador.backend.repositorios.IRepositorioEmpresa;
import com.integrador.backend.repositorios.IRepositorioReto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ServicioEmpresa {

    private final IRepositorioEmpresa repositorio;
    private final IRepositorioReto repositorioReto;

    public List<Empresa> listar() {
        return repositorio.findAll();
    }

    public Optional<Empresa> buscarPorId(UUID id) {
        return repositorio.findById(id);
    }

    public Empresa guardar(Empresa empresa) {
        empresa.setId(null); // el id lo genera el servidor
        if (empresa.getActiva() == null) {
            empresa.setActiva(true);
        }
        return repositorio.save(empresa);
    }

    public Optional<Empresa> actualizar(UUID id, Empresa datos) {
        return repositorio.findById(id).map(existente -> {
            existente.setNombre(datos.getNombre());
            existente.setNit(datos.getNit());
            existente.setSector(datos.getSector());
            existente.setContacto(datos.getContacto());
            existente.setCorreo(datos.getCorreo());
            existente.setTelefono(datos.getTelefono());
            existente.setUbicacion(datos.getUbicacion());
            existente.setPrioridadId(datos.getPrioridadId());
            if (datos.getActiva() != null) {
                existente.setActiva(datos.getActiva());
            }
            return repositorio.save(existente);
        });
    }

    public boolean eliminar(UUID id) {
        if (!repositorio.existsById(id)) {
            return false;
        }
        if (repositorioReto.existsByEmpresaId(id)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "No se puede eliminar: tiene retos relacionados");
        }
        repositorio.deleteById(id);
        return true;
    }
}
