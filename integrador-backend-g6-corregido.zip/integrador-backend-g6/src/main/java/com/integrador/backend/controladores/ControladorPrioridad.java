package com.integrador.backend.controladores;

import com.integrador.backend.modelos.Prioridad;
import com.integrador.backend.servicios.ServicioPrioridad;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/prioridades")
@RequiredArgsConstructor
public class ControladorPrioridad {

    private final ServicioPrioridad servicio;

    @GetMapping
    public List<Prioridad> listar() {
        return servicio.listar();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Prioridad> buscarPorId(@PathVariable UUID id) {
        return servicio.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Prioridad> crear(@Valid @RequestBody Prioridad prioridad) {
        return ResponseEntity.status(HttpStatus.CREATED).body(servicio.guardar(prioridad));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Prioridad> actualizar(@PathVariable UUID id, @Valid @RequestBody Prioridad prioridad) {
        return servicio.actualizar(id, prioridad)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable UUID id) {
        return servicio.eliminar(id)
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }
}
