import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { authService } from '../services/authService.js'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [checking, setChecking] = useState(true)

  useEffect(() => {
    let active = true
    authService.restore()
      .then(current => { if (active) setUser(current) })
      .catch(() => { authService.logout() })
      .finally(() => { if (active) setChecking(false) })
    return () => { active = false }
  }, [])

  const login = useCallback(async credentials => setUser(await authService.login(credentials)), [])
  const register = useCallback(async details => setUser(await authService.register(details)), [])
  const logout = useCallback(() => { authService.logout(); setUser(null); window.location.hash = '' }, [])
  const refresh = useCallback(async () => {
    try { setUser(await authService.restore()) } catch { logout() }
  }, [logout])

  const value = useMemo(() => ({ user, checking, login, register, logout, refresh }), [user, checking, login, register, logout, refresh])
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => useContext(AuthContext)
