export const getName = (data, source, id) => data[source]?.find(item => item.id === id)?.nombre ?? 'No encontrado'

export const formatDate = value => value
  ? new Date(`${value}T12:00:00`).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' })
  : '—'

export const initials = name => (name || '?').trim().split(/\s+/).slice(0, 2).map(word => word[0]).join('').toUpperCase()

export const firstName = name => name.split(' ')[0]

export const displayCount = count => String(count).padStart(2, '0')

export const todayString = () => {
  const date = new Date()
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
}

// Valor legible de una columna: resuelve relaciones, conteos y booleanos.
export const cellValue = (data, item, col) => {
  if (col.relation) return item[col.field] ? getName(data, col.relation, item[col.field]) : '—'
  if (col.count) return data[col.count.source].filter(row => row[col.count.by] === item.id).length
  if (col.type === 'boolean') return item[col.field] ? (col.labels?.[0] ?? 'Sí') : (col.labels?.[1] ?? 'No')
  return item[col.field]
}

// Minúsculas y sin tildes, para búsquedas tolerantes («innovacion» encuentra «Innovación»).
export const normalizeText = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('es').trim()
