package com.integrador.backend.modelos;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.util.UUID;

@Entity
@Table(name = "usuarios")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @JdbcTypeCode(SqlTypes.CHAR)
    @Column(name = "id", length = 36, nullable = false, updatable = false)
    private UUID id;

    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 150, message = "El nombre no puede superar 150 caracteres")
    @Column(length = 150, nullable = false)
    private String nombre;

    @NotBlank(message = "El correo es obligatorio")
    @Email(message = "El correo no tiene un formato válido")
    @Size(max = 120, message = "El correo no puede superar 120 caracteres")
    @Column(length = 120, nullable = false, unique = true)
    private String correo;

    @NotBlank(message = "El cargo es obligatorio")
    @Column(length = 80, nullable = false)
    private String cargo;

    // "Administrador", "Evaluador" o "Participante"
    @NotBlank(message = "El rol es obligatorio")
    @Column(length = 30, nullable = false)
    private String rol;

    // "Activo" o "Inactivo"
    @NotBlank(message = "El estado es obligatorio")
    @Column(length = 20, nullable = false)
    private String estado;

    // Solo se escribe: llega en el JSON, pero NUNCA se devuelve al frontend.
    // En la base se guarda el hash BCrypt, jamás el texto plano.
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Column(name = "password_hash", length = 100)
    private String password;
}
