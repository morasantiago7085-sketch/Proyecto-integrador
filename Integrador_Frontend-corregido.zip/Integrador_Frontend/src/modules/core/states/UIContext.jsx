import { createContext, useContext, useMemo, useState } from 'react'

const UIContext = createContext(null)

// Estado de interfaz compartido: búsquedas, filtros y vista (tarjetas/tabla) por módulo.
export function UIProvider({ children }) {
  const [searches, setSearches] = useState({})
  const [filters, setFilters] = useState({})
  const [viewMode, setViewMode] = useState('cards')

  const value = useMemo(() => ({
    searches, filters, viewMode, setViewMode,
    setSearch: (type, text) => setSearches(prev => ({ ...prev, [type]: text })),
    setFilter: (type, text) => setFilters(prev => ({ ...prev, [type]: text })),
  }), [searches, filters, viewMode])

  return <UIContext.Provider value={value}>{children}</UIContext.Provider>
}

export const useUI = () => useContext(UIContext)
