package com.integrador.backend.servicios;

import com.integrador.backend.modelos.Reto;
import com.integrador.backend.repositorios.IRepositorioRegistro;
import com.integrador.backend.repositorios.IRepositorioReto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ServicioReto {

    private final IRepositorioReto repositorio;
    private final IRepositorioRegistro repositorioRegistro;

    public List<Reto> listar() {
        return repositorio.findAll();
    }

    public Optional<Reto> buscarPorId(UUID id) {
        return repositorio.findById(id);
    }

    public Reto guardar(Reto reto) {
        reto.setId(null); // el id lo genera el servidor
        validarFechas(reto);
        return repositorio.save(reto);
    }

    public Optional<Reto> actualizar(UUID id, Reto datos) {
        return repositorio.findById(id).map(existente -> {
            validarFechas(datos);
            existente.setNombre(datos.getNombre());
            existente.setDescripcion(datos.getDescripcion());
            existente.setEmpresaId(datos.getEmpresaId());
            existente.setCategoriaId(datos.getCategoriaId());
            existente.setPrioridadId(datos.getPrioridadId());
            existente.setEstado(datos.getEstado());
            existente.setFechaInicio(datos.getFechaInicio());
            existente.setFechaFin(datos.getFechaFin());
            return repositorio.save(existente);
        });
    }

    public boolean eliminar(UUID id) {
        if (!repositorio.existsById(id)) {
            return false;
        }
        if (repositorioRegistro.existsByRetoId(id)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "No se puede eliminar: tiene registros relacionados");
        }
        repositorio.deleteById(id);
        return true;
    }

    private void validarFechas(Reto reto) {
        if (reto.getFechaInicio() != null && reto.getFechaFin() != null
                && reto.getFechaFin().isBefore(reto.getFechaInicio())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "La fecha de cierre no puede ser anterior a la de inicio");
        }
    }
}
