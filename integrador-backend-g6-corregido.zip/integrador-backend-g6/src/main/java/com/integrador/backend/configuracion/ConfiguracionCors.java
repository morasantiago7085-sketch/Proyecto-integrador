package com.integrador.backend.configuracion;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/** CORS en un solo lugar para todos los controladores bajo /api. */
@Configuration
public class ConfiguracionCors implements WebMvcConfigurer {

    // Se puede cambiar en application.properties con app.cors.origen=...
    @Value("${app.cors.origen:http://localhost:5173}")
    private String origenPermitido;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOrigins(origenPermitido)
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*");
    }
}
