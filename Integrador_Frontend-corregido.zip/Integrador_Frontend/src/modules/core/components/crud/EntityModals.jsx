import { useMemo, useRef, useState } from 'react'
import { Check, CircleAlert, Info, LockKeyhole, Trash2, X } from 'lucide-react'
import { entityConfig } from '../../lib/registry.js'
import { getName, todayString } from '../../utils/formatters.js'
import { makeId } from '../../utils/ids.js'
import { ModalShell } from '../../design-system/UI.jsx'
import { useAuth } from '../../../auth/states/AuthContext.jsx'
import { isAdmin } from '../../../auth/lib/permissions.js'
import { isEmail } from '../../../auth/utils/validators.js'

const relationBlocking = {
  empresas: [['retos', 'empresaId', 'retos']],
  categorias: [['retos', 'categoriaId', 'retos']],
  prioridades: [['retos', 'prioridadId', 'retos'], ['empresas', 'prioridadId', 'empresas']],
  usuarios: [['registros', 'usuarioId', 'registros']],
  retos: [['registros', 'retoId', 'registros']],
}

const OTHER = '__otro__'
const DATE_DEFAULTS = ['fechaRegistro', 'fechaInicio']

const initialValue = (field, item, initialValues) => {
  const existing = item?.[field.name] ?? initialValues?.[field.name]
  if (field.type === 'boolean') return String(existing ?? true)
  if (field.transient) return ''
  if (existing !== undefined && existing !== null) return existing
  if (DATE_DEFAULTS.includes(field.name)) return todayString()
  if (field.type === 'select') return field.options[0]
  return ''
}

// Las relaciones solo ofrecen empresas activas y usuarios activos (más el valor ya elegido).
const isAvailable = (option, selected) => option.id === selected || (option.activa !== false && option.estado !== 'Inactivo')

export function FormModal({ type, item, data, onClose, onSave, initialValues }) {
  const cfg = entityConfig[type]
  const { user } = useAuth()
  const selfOnly = type === 'registros' && !isAdmin(user) && user.rol === 'Participante'
  const initial = useMemo(() => {
    const values = cfg.fields.reduce((acc, field) => ({ ...acc, [field.name]: initialValue(field, item, initialValues) }), {})
    if (selfOnly) values.usuarioId = user.id
    return values
  }, [cfg, item, initialValues, selfOnly, user.id])
  const [form, setForm] = useState(initial)
  const [error, setError] = useState('')
  const [otherName, setOtherName] = useState(false)
  const touched = useRef(new Set(item ? cfg.fields.map(field => field.name) : []))

  const change = (field, value) => {
    touched.current.add(field.name)
    setForm(current => {
      const next = { ...current, [field.name]: value }
      // Hereda valores sugeridos (p. ej. la prioridad de la empresa) mientras no se editen a mano.
      for (const target of cfg.fields) {
        const rule = target.defaultFrom
        if (rule?.field === field.name && !touched.current.has(target.name)) {
          next[target.name] = data[rule.source].find(row => row.id === value)?.[rule.sourceField] ?? ''
        }
      }
      return next
    })
    setError('')
  }

  // Campo «catálogo»: elegir un valor ya configurado (y heredar sus datos) o escribir uno nuevo con «Otro».
  const pickCatalog = (field, value) => {
    setError('')
    if (value === OTHER) {
      setOtherName(true)
      setForm(current => ({ ...current, [field.name]: '' }))
      return
    }
    setOtherName(false)
    const previous = data[field.source].find(row => row[field.name] === value)
    setForm(current => {
      const next = { ...current, [field.name]: value }
      for (const name of field.prefill ?? []) {
        if (!touched.current.has(name) && previous && !String(current[name] ?? '').trim()) next[name] = previous[name] ?? ''
      }
      return next
    })
  }

  const submit = event => {
    event.preventDefault()
    const missing = cfg.fields.find(field => {
      const required = field.required || (field.requiredOnCreate && !item)
      return required && !String(form[field.name] ?? '').trim()
    })
    if (missing) return setError(`Completa el campo «${missing.label}».`)
    if (type === 'retos' && form.fechaFin < form.fechaInicio) return setError('La fecha de cierre no puede ser anterior a la fecha de inicio.')
    if (type === 'registros' && data.registros.some(reg => reg.usuarioId === form.usuarioId && reg.retoId === form.retoId && reg.id !== item?.id)) {
      return setError('Este usuario ya está inscrito en ese reto. Elige otra combinación.')
    }
    if ((type === 'usuarios' || type === 'empresas') && form.correo && !isEmail(form.correo)) return setError('Ingresa un correo electrónico válido.')
    if (type === 'empresas' && !/^[\d\s()+-]{7,20}$/.test(form.telefono.trim())) return setError('Ingresa un teléfono válido (solo números, mínimo 7 dígitos).')
    if (type === 'categorias' && data.categorias.some(row => row.nombre.trim().toLowerCase() === form.nombre.trim().toLowerCase() && row.id !== item?.id)) return setError('Ya existe una categoría con ese nombre.')
    if (type === 'usuarios' && data.usuarios.some(row => row.correo.toLowerCase() === form.correo.toLowerCase() && row.id !== item?.id)) return setError('Ese correo ya está registrado.')
    if (type === 'usuarios' && form.password && form.password.length < 8) return setError('La contraseña debe tener al menos 8 caracteres.')
    if (type === 'empresas' && data.empresas.some(row => row.nit.trim() === form.nit.trim() && row.id !== item?.id)) return setError('Ya existe una empresa con ese NIT.')

    const cleaned = {}
    for (const field of cfg.fields) {
      const value = form[field.name]
      if (field.type === 'number') cleaned[field.name] = Number(value)
      else if (field.type === 'boolean') cleaned[field.name] = value === 'true' || value === true
      else if (field.transient) { if (String(value).trim()) cleaned[field.name] = String(value) }
      else cleaned[field.name] = String(value ?? '').trim()
    }
    onSave(type, { ...cleaned, id: item?.id ?? makeId() }, Boolean(item))
  }

  const renderControl = field => {
    const value = form[field.name] ?? ''
    const onChange = event => change(field, event.target.value)
    if (field.type === 'catalog' && !item) {
      const names = [...new Set(data[field.source].map(row => row[field.name]).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es'))
      const typing = otherName || names.length === 0
      return <>
        <select value={typing ? OTHER : value} onChange={event => pickCatalog(field, event.target.value)}>
          {!typing && !value && <option value="">Selecciona un reto ya configurado…</option>}
          {names.map(name => <option key={name} value={name}>{name}</option>)}
          <option value={OTHER}>Otro (escribir uno nuevo)</option>
        </select>
        {typing && <input className="catalog-input" autoFocus={otherName} required value={value} placeholder={field.placeholder ?? ''} onChange={onChange}/>}
      </>
    }
    if (field.type === 'textarea') return <textarea rows={4} value={value} placeholder={field.placeholder ?? ''} onChange={onChange}/>
    if (field.type === 'relation') {
      const locked = selfOnly && field.name === 'usuarioId'
      const options = data[field.source].filter(option => (locked ? option.id === user.id : isAvailable(option, value)))
      return <select required={field.required} disabled={locked} value={value} onChange={onChange}>
        <option value="">Selecciona {field.label.toLowerCase()}</option>
        {options.map(option => <option key={option.id} value={option.id}>{option.nombre}</option>)}
      </select>
    }
    if (field.type === 'boolean') {
      const [yes, no] = field.labels ?? ['Sí', 'No']
      return <select value={value} onChange={onChange}><option value="true">{yes}</option><option value="false">{no}</option></select>
    }
    if (field.type === 'select') return <select required={field.required} value={value} onChange={onChange}>{field.options.map(option => <option key={option}>{option}</option>)}</select>
    return <input required={field.required || (field.requiredOnCreate && !item)} type={field.type || 'text'} min={field.min} minLength={field.minLength}
      autoComplete={field.type === 'password' ? 'new-password' : undefined} placeholder={field.placeholder ?? ''} value={value} onChange={onChange}/>
  }

  return <ModalShell onClose={onClose} size="large"><form onSubmit={submit}>
    <div className="modal-header"><div><div className="eyebrow">{item ? 'EDITAR REGISTRO' : 'CREAR NUEVO REGISTRO'}</div><h2>{item ? `Editar ${cfg.singular}` : cfg.newLabel ?? `Nuevo ${cfg.singular}`}</h2><p>Completa la información para {item ? 'actualizar' : 'agregar'} {type === 'registros' ? 'la participación' : `este ${cfg.singular}`}.</p></div><button type="button" className="modal-x" onClick={onClose} aria-label="Cerrar"><X size={21}/></button></div>
    <div className="modal-body">
      <div className="form-grid">{cfg.fields.map(field => <label key={field.name} className={`form-field ${field.span === 2 ? 'full' : ''}`}>
        <span>{field.label}{(field.required || (field.requiredOnCreate && !item)) && <em>*</em>}</span>
        {renderControl(field)}
        {item && field.hintOnEdit && <small className="field-hint">{field.hintOnEdit}</small>}
      </label>)}</div>
      {type === 'registros' && <div className="form-hint"><Info size={16}/> Cada usuario puede tener una inscripción por reto.</div>}
      {type === 'retos' && <div className="form-hint"><Info size={16}/> La prioridad se sugiere según la empresa elegida; puedes cambiarla para este reto.</div>}
      {error && <div className="form-error" role="alert"><CircleAlert size={17}/>{error}</div>}
    </div>
    <div className="modal-footer"><button className="btn btn-outline" type="button" onClick={onClose}>Cancelar</button><button className="btn btn-primary" type="submit"><Check size={18}/>{item ? 'Guardar cambios' : 'Guardar'}</button></div>
  </form></ModalShell>
}

export function DeleteModal({ type, item, data, onClose, onConfirm }) {
  const { user } = useAuth()
  const links = (relationBlocking[type] || []).map(([table, field, label]) => ({
    label,
    count: data[table].filter(row => row[field] === item.id).length,
  })).filter(row => row.count > 0)
  const isSelf = type === 'usuarios' && item.id === user.id
  const canDelete = links.length === 0 && !isSelf
  const label = item.nombre || `${getName(data, 'usuarios', item.usuarioId)} · ${getName(data, 'retos', item.retoId)}`

  return <ModalShell onClose={onClose} size="small"><div className="delete-body">
    <span className={`delete-icon ${canDelete ? '' : 'blocked'}`}>{canDelete ? <Trash2 size={27}/> : <LockKeyhole size={27}/>}</span>
    <h2>{canDelete ? '¿Eliminar registro?' : isSelf ? 'No puedes eliminar tu cuenta' : 'Este registro está en uso'}</h2>
    <p>{canDelete
      ? <>Vas a eliminar <strong>{label}</strong>. Esta acción no se puede deshacer.</>
      : isSelf
        ? <>Estás usando la cuenta <strong>{item.nombre}</strong>. Pide a otro administrador que la elimine.</>
        : <>No puedes eliminar <strong>{item.nombre}</strong> porque tiene información relacionada. Primero elimina o reasigna los registros dependientes.</>}</p>
    {links.length > 0 && <div className="dependency-list">{links.map(row => <span key={row.label}><CircleAlert size={16}/> {row.count} {row.label} relacionado{row.count === 1 ? '' : 's'}</span>)}</div>}
  </div><div className="modal-footer"><button className="btn btn-outline" onClick={onClose}>Cancelar</button>{canDelete && <button className="btn btn-danger" onClick={() => onConfirm(type, item.id)}><Trash2 size={17}/> Eliminar</button>}</div></ModalShell>
}
