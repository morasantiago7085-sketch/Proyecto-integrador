package com.integrador.backend.servicios;

import com.integrador.backend.modelos.Categoria;
import com.integrador.backend.repositorios.IRepositorioCategoria;
import com.integrador.backend.repositorios.IRepositorioReto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ServicioCategoria {

    private final IRepositorioCategoria repositorio;
    private final IRepositorioReto repositorioReto;

    public List<Categoria> listar() {
        return repositorio.findAll();
    }

    public Optional<Categoria> buscarPorId(UUID id) {
        return repositorio.findById(id);
    }

    public Categoria guardar(Categoria categoria) {
        categoria.setId(null); // el id lo genera el servidor
        return repositorio.save(categoria);
    }

    public Optional<Categoria> actualizar(UUID id, Categoria datos) {
        return repositorio.findById(id).map(existente -> {
            existente.setNombre(datos.getNombre());
            existente.setDescripcion(datos.getDescripcion());
            existente.setAreaResponsable(datos.getAreaResponsable());
            return repositorio.save(existente);
        });
    }

    public boolean eliminar(UUID id) {
        if (!repositorio.existsById(id)) {
            return false;
        }
        if (repositorioReto.existsByCategoriaId(id)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "No se puede eliminar: tiene retos relacionados");
        }
        repositorio.deleteById(id);
        return true;
    }
}
