import { useCallback, useEffect, useState } from 'react'

const read = () => window.location.hash.replace(/^#\/?/, '') || 'dashboard'

export function useHashRoute() {
  const [route, setRoute] = useState(read)

  useEffect(() => {
    const sync = () => setRoute(read())
    window.addEventListener('hashchange', sync)
    return () => window.removeEventListener('hashchange', sync)
  }, [])

  const navigate = useCallback(next => {
    window.location.hash = next
    setRoute(next)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [])

  return [route, navigate]
}
