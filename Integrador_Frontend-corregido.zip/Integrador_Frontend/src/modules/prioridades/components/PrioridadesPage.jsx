import EntityPage from '../../core/components/crud/EntityPage.jsx'

export default function PrioridadesPage() {
  return <EntityPage type="prioridades"/>
}
