# Backend — Proyecto Integrador III (Equipo 6)

API REST desarrollada con **Spring Boot** para el Proyecto Integrador III de CESDE (Nuevas Tecnologías de Programación). El backend guarda en MySQL la información de las tablas del proyecto (Empresa, Reto, Categoría, Prioridad, Registro y Usuario) y la expone para que el frontend en React la consuma.

## Tecnologías

| Herramienta | Uso |
| --- | --- |
| Java 21 | Lenguaje |
| Spring Boot (Maven) | Framework del backend, creado con Spring Initializr |
| MySQL (XAMPP) | Base de datos `integrador_db` |
| IntelliJ IDEA | Entorno de desarrollo |

- Paquete base: `com.integrador.backend`
- Artifact: `backend`

## Estructura del proyecto

Se sigue la estructura del ejemplo del profesor, con una capa por paquete:

```
com.integrador.backend
├── controladores   → reciben las peticiones HTTP (lo que llama el frontend)
├── modelos         → entidades: cada clase representa una tabla
├── repositorios    → acceso a la base de datos
├── servicios       → lógica del negocio
├── configuracion   → configuración general (CORS)
├── excepciones     → manejo global de errores (400 datos inválidos, 409 duplicados)
└── BackendApplication (clase que arranca el proyecto)
```

Cómo viaja una petición: **React → Controlador → Servicio → Repositorio → MySQL**.

## Estado actual

Hecho:
- CRUD completo de las seis tablas: `Prioridad`, `Categoria`, `Empresa`, `Reto`, `Usuario` y `Registro` (modelo, repositorio, servicio y controlador).
- `GET /api/data`: devuelve las seis listas en un solo objeto (el frontend carga todo con esta ruta).
- Registro e inicio de sesión reales: `POST /api/auth/register`, `POST /api/auth/login` y `GET /api/auth/me`. Las contraseñas se guardan con BCrypt y el token va firmado (HMAC-SHA256).
- CORS centralizado en `ConfiguracionCors` y errores con formato `{ estado, mensaje }` en `ManejadorErrores`.
- Al arrancar por primera vez se crea un administrador (`admin@nexo.co` / `Admin123*`) y cuatro prioridades básicas, solo si hacen falta. Con esa cuenta se administran todos los módulos.
- No se puede eliminar un registro que tiene dependientes (responde 409), igual que el frontend.

Pendiente:
- Que el backend haga cumplir los permisos por rol (hoy los oculta solo el frontend).
- Confirmar con el profesor que todas las tablas usan MySQL.

## Cómo ejecutarlo

1. Abre **XAMPP** e inicia el módulo **MySQL**.
2. Verifica que exista la base de datos `integrador_db` (se puede ver en phpMyAdmin).
3. Abre el proyecto en IntelliJ y revisa `src/main/resources/application.properties`: el usuario y la contraseña de MySQL deben ser los de tu equipo local.
4. Ejecuta la clase con `@SpringBootApplication` (botón verde de ejecutar).
5. Si todo está bien, la consola muestra que la aplicación inició. Por defecto escucha en `http://localhost:8080`.

## Cómo probarlo

- Pruebas automáticas: `./mvnw test` (usa H2 en memoria, no necesita MySQL).
- Pruebas manuales con Postman contra `http://localhost:8080`: `/api/prioridades`, `/api/empresas`, `/api/categorias` y `/api/registros` (GET, POST, PUT y DELETE).

## Cómo agregar tu tabla

Toma `Prioridad` como ejemplo. Cada integrante crea, en los cuatro paquetes, las clases de su tabla. Ejemplo con `Reto`:

| Paquete | Clase |
| --- | --- |
| `modelos` | `Reto` |
| `repositorios` | `IRepositorioReto` |
| `servicios` | `ServicioReto` |
| `controladores` | `ControladorReto` |

Usa `UUID` con `@JdbcTypeCode(SqlTypes.CHAR)` y `@Column(length = 36)` para el id (ver `Categoria`), y agrega validaciones (`@NotBlank`, `@Size`...) a los campos obligatorios.

Mantén los nombres de las columnas iguales a los de las demás etapas del proyecto (simulación, exportación y limpieza de datos), para que todo conecte.

## Flujo de trabajo con Git

- Repositorio: `integrador-backend-g6`.
- Ramas: `main` y `develop`. Cada historia de usuario va en su propia rama `feature/...` creada desde `develop`.
- El trabajo entra a `develop` mediante Pull Request.
- No modifiques archivos de otra tabla sin avisar al equipo.

## Seguridad

- **No subas contraseñas ni credenciales** a GitHub. Si `application.properties` tiene tu contraseña de MySQL, no la publiques.
- Cambia `app.auth.secreto` en `application.properties` por uno propio; con él se firman los tokens de sesión.
- Las contraseñas de los usuarios nunca se devuelven en las respuestas ni se guardan en texto plano.
