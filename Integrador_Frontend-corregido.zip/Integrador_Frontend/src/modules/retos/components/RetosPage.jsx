import { Plus, Sparkles } from 'lucide-react'
import EntityPage from '../../core/components/crud/EntityPage.jsx'
import { useData } from '../../core/states/DataContext.jsx'
import { useModals } from '../../core/states/ModalContext.jsx'
import { useAuth } from '../../auth/states/AuthContext.jsx'
import { can } from '../../auth/lib/permissions.js'
import ChallengeCard from './ChallengeCard.jsx'

export default function RetosPage() {
  const { data } = useData()
  const { user } = useAuth()
  const { openCreate, openView, openEdit } = useModals()
  const registrationValues = user.rol === 'Participante' ? { usuarioId: user.id } : undefined

  const intro = can(user, 'create', 'registros') && <div className="retos-intro">
    <div className="retos-intro-icon"><Sparkles size={21}/></div>
    <div><strong>Transforma desafíos en oportunidades</strong><p>Organiza retos reales de empresas e invita a la comunidad a proponer soluciones.</p></div>
    <button onClick={() => openCreate('registros', registrationValues)}><Plus size={17}/> Nueva inscripción</button>
  </div>

  return <EntityPage type="retos" viewable intro={intro}
    renderCards={(reto, index) => <ChallengeCard key={reto.id} reto={reto} data={data} onView={openView} onEdit={can(user, 'update', 'retos') ? openEdit : undefined} index={index}/>}/>
}
