package com.integrador.backend.servicios;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Optional;
import java.util.UUID;

/**
 * Token firmado con HMAC-SHA256: "<idUsuario>:<expira>" en Base64 + "." + firma.
 * Sin estado en el servidor, así que sigue siendo válido si se reinicia la API.
 * Se configura con app.auth.secreto y app.auth.horas en application.properties.
 */
@Service
public class ServicioToken {

    private final byte[] clave;
    private final long duracionMs;

    public ServicioToken(
            @Value("${app.auth.secreto:cambia-este-secreto-antes-de-entregar-0123456789}") String secreto,
            @Value("${app.auth.horas:12}") long horas) {
        this.clave = secreto.getBytes(StandardCharsets.UTF_8);
        this.duracionMs = horas * 3_600_000L;
    }

    public String generar(UUID idUsuario) {
        long expira = System.currentTimeMillis() + duracionMs;
        String cuerpo = Base64.getUrlEncoder().withoutPadding()
                .encodeToString((idUsuario + ":" + expira).getBytes(StandardCharsets.UTF_8));
        return cuerpo + "." + firmar(cuerpo);
    }

    /** Devuelve el id del usuario si el token es auténtico y no ha expirado. */
    public Optional<UUID> validar(String token) {
        try {
            if (token == null) {
                return Optional.empty();
            }
            int punto = token.indexOf('.');
            if (punto < 1) {
                return Optional.empty();
            }
            String cuerpo = token.substring(0, punto);
            String firma = token.substring(punto + 1);
            if (!MessageDigest.isEqual(firmar(cuerpo).getBytes(StandardCharsets.UTF_8),
                    firma.getBytes(StandardCharsets.UTF_8))) {
                return Optional.empty();
            }
            String[] partes = new String(Base64.getUrlDecoder().decode(cuerpo), StandardCharsets.UTF_8).split(":");
            if (partes.length != 2 || Long.parseLong(partes[1]) < System.currentTimeMillis()) {
                return Optional.empty();
            }
            return Optional.of(UUID.fromString(partes[0]));
        } catch (RuntimeException e) {
            return Optional.empty();
        }
    }

    private String firmar(String texto) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(clave, "HmacSHA256"));
            return Base64.getUrlEncoder().withoutPadding()
                    .encodeToString(mac.doFinal(texto.getBytes(StandardCharsets.UTF_8)));
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("No se pudo firmar el token", e);
        }
    }
}
