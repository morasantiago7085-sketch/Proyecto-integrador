package com.integrador.backend.servicios;

import com.integrador.backend.modelos.Usuario;
import com.integrador.backend.repositorios.IRepositorioRegistro;
import com.integrador.backend.repositorios.IRepositorioUsuario;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ServicioUsuario {

    // Mismos valores que usa el frontend (auth/lib/cargos.js)
    static final List<String> CARGOS = List.of(
            "Desarrollador Full Stack", "Desarrollador Frontend", "Desarrollador Backend",
            "Ingeniero DevOps", "Especialista en QA");
    static final List<String> ROLES = List.of("Administrador", "Evaluador", "Participante");
    static final List<String> ESTADOS = List.of("Activo", "Inactivo");

    private static final String ADMIN = "Administrador";
    private static final String ACTIVO = "Activo";

    private final IRepositorioUsuario repositorio;
    private final IRepositorioRegistro repositorioRegistro;
    private final PasswordEncoder encoder;

    public List<Usuario> listar() {
        return repositorio.findAll();
    }

    public Optional<Usuario> buscarPorId(UUID id) {
        return repositorio.findById(id);
    }

    public Optional<Usuario> buscarPorCorreo(String correo) {
        return repositorio.findByCorreoIgnoreCase(correo.trim());
    }

    public boolean contrasenaCoincide(Usuario usuario, String contrasena) {
        return usuario.getPassword() != null && encoder.matches(contrasena, usuario.getPassword());
    }

    public Usuario guardar(Usuario usuario) {
        usuario.setId(null); // el id lo genera el servidor
        usuario.setCorreo(usuario.getCorreo().trim());
        validar(usuario, null);
        validarContrasena(usuario.getPassword(), true);
        usuario.setPassword(encoder.encode(usuario.getPassword()));
        return repositorio.save(usuario);
    }

    /** Registro público: siempre entra como Participante activo. */
    public Usuario registrar(String nombre, String correo, String cargo, String contrasena) {
        Usuario nuevo = new Usuario();
        nuevo.setNombre(nombre.trim());
        nuevo.setCorreo(correo);
        nuevo.setCargo(cargo);
        nuevo.setRol("Participante");
        nuevo.setEstado(ACTIVO);
        nuevo.setPassword(contrasena);
        return guardar(nuevo);
    }

    public Optional<Usuario> actualizar(UUID id, Usuario datos) {
        return repositorio.findById(id).map(existente -> {
            datos.setCorreo(datos.getCorreo().trim());
            validar(datos, id);
            if (ADMIN.equals(existente.getRol()) && ACTIVO.equals(existente.getEstado())
                    && (!ADMIN.equals(datos.getRol()) || !ACTIVO.equals(datos.getEstado()))) {
                exigirOtroAdministrador(id);
            }
            existente.setNombre(datos.getNombre());
            existente.setCorreo(datos.getCorreo());
            existente.setCargo(datos.getCargo());
            existente.setRol(datos.getRol());
            existente.setEstado(datos.getEstado());
            // Contraseña vacía = conservar la actual
            if (datos.getPassword() != null && !datos.getPassword().isBlank()) {
                validarContrasena(datos.getPassword(), true);
                existente.setPassword(encoder.encode(datos.getPassword()));
            }
            return repositorio.save(existente);
        });
    }

    public boolean eliminar(UUID id) {
        Optional<Usuario> usuario = repositorio.findById(id);
        if (usuario.isEmpty()) {
            return false;
        }
        if (repositorioRegistro.existsByUsuarioId(id)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "No se puede eliminar: tiene registros relacionados");
        }
        if (ADMIN.equals(usuario.get().getRol()) && ACTIVO.equals(usuario.get().getEstado())) {
            exigirOtroAdministrador(id);
        }
        repositorio.deleteById(id);
        return true;
    }

    private void validar(Usuario usuario, UUID idActual) {
        boolean correoRepetido = idActual == null
                ? repositorio.existsByCorreoIgnoreCase(usuario.getCorreo())
                : repositorio.existsByCorreoIgnoreCaseAndIdNot(usuario.getCorreo(), idActual);
        if (correoRepetido) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Ese correo ya está registrado");
        }
        if (!CARGOS.contains(usuario.getCargo())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Selecciona un cargo válido");
        }
        if (!ROLES.contains(usuario.getRol())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Selecciona un rol válido");
        }
        if (!ESTADOS.contains(usuario.getEstado())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Selecciona un estado válido");
        }
    }

    private void validarContrasena(String contrasena, boolean obligatoria) {
        if ((contrasena == null || contrasena.isEmpty()) ? obligatoria : contrasena.length() < 8) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "La contraseña debe tener al menos 8 caracteres");
        }
    }

    private void exigirOtroAdministrador(UUID idExcluido) {
        if (repositorio.countByRolAndEstadoAndIdNot(ADMIN, ACTIVO, idExcluido) == 0) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Debe existir al menos un administrador activo");
        }
    }
}
