import { useState } from 'react'
import { ArrowRight, CircleAlert, Eye, EyeOff, KeyRound, Loader2, ShieldCheck } from 'lucide-react'
import { Logo } from '../../core/design-system/UI.jsx'
import { API_MODE } from '../../core/services/api.js'
import { DEMO_ADMIN } from '../../core/services/seed.js'
import { useAuth } from '../states/AuthContext.jsx'
import { CARGOS } from '../lib/cargos.js'
import { isEmail, validateRegister } from '../utils/validators.js'

function PasswordInput({ id, value, onChange, placeholder, autoComplete }) {
  const [visible, setVisible] = useState(false)
  return <span className="password-input">
    <input id={id} type={visible ? 'text' : 'password'} value={value} onChange={onChange} placeholder={placeholder} autoComplete={autoComplete} required/>
    <button type="button" onClick={() => setVisible(v => !v)} aria-label={visible ? 'Ocultar contraseña' : 'Mostrar contraseña'}>{visible ? <EyeOff size={17}/> : <Eye size={17}/>}</button>
  </span>
}

export default function AuthPage() {
  const { login, register } = useAuth()
  const [mode, setMode] = useState('login')
  const [form, setForm] = useState({ nombre: '', correo: '', cargo: CARGOS[0].value, password: '', confirm: '' })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const set = field => event => { setForm(current => ({ ...current, [field]: event.target.value })); setError('') }
  const switchMode = next => { setMode(next); setError('') }

  const submit = async event => {
    event.preventDefault()
    const problem = mode === 'login'
      ? (!isEmail(form.correo) ? 'Ingresa un correo electrónico válido.' : '')
      : validateRegister(form)
    if (problem) return setError(problem)
    setBusy(true)
    try {
      if (mode === 'login') await login({ correo: form.correo.trim(), password: form.password })
      else await register({ nombre: form.nombre, correo: form.correo.trim(), cargo: form.cargo, password: form.password })
      window.location.hash = 'dashboard'
    } catch (err) {
      setError(err.message)
      setBusy(false)
    }
  }

  const fillAdmin = () => { setForm(current => ({ ...current, ...DEMO_ADMIN })); setError('') }

  return <div className="auth-shell">
    <aside className="auth-hero">
      <Logo/>
      <div>
        <div className="eyebrow">PLATAFORMA DE RETOS EMPRESARIALES</div>
        <h1>Las buenas ideas nacen de grandes <em>retos.</em></h1>
        <p>Conecta empresas, prioriza sus desafíos y reúne al talento TI que puede resolverlos.</p>
      </div>
      <ul className="auth-points">
        <li><ShieldCheck size={18}/> Acceso por rol: administrador, evaluador y participante.</li>
        <li><KeyRound size={18}/> Regístrate con tu cargo profesional en TI.</li>
      </ul>
    </aside>

    <main className="auth-panel">
      <form className="auth-card" onSubmit={submit} noValidate>
        <div className="auth-tabs" role="tablist">
          <button type="button" role="tab" aria-selected={mode === 'login'} className={mode === 'login' ? 'selected' : ''} onClick={() => switchMode('login')}>Iniciar sesión</button>
          <button type="button" role="tab" aria-selected={mode === 'register'} className={mode === 'register' ? 'selected' : ''} onClick={() => switchMode('register')}>Crear cuenta</button>
        </div>
        <h2>{mode === 'login' ? 'Bienvenido de nuevo' : 'Crea tu cuenta'}</h2>
        <p className="auth-sub">{mode === 'login' ? 'Ingresa con tu correo y contraseña.' : 'Elige el cargo que mejor te describe.'}</p>

        <div className="auth-fields">
          {mode === 'register' && <label className="form-field"><span>Nombre completo<em>*</em></span><input value={form.nombre} onChange={set('nombre')} autoComplete="name" placeholder="Ej. Laura Gómez" required/></label>}
          <label className="form-field"><span>Correo electrónico<em>*</em></span><input type="email" value={form.correo} onChange={set('correo')} autoComplete="email" placeholder="tu@correo.com" required/></label>

          {mode === 'register' && <fieldset className="cargo-picker">
            <legend>Cargo<em>*</em></legend>
            {CARGOS.map(cargo => <label key={cargo.value} className={`cargo-option ${form.cargo === cargo.value ? 'selected' : ''}`}>
              <input type="radio" name="cargo" value={cargo.value} checked={form.cargo === cargo.value} onChange={set('cargo')}/>
              <span><strong>{cargo.value}</strong><small>{cargo.description}</small></span>
            </label>)}
          </fieldset>}

          <label className="form-field"><span>Contraseña<em>*</em></span><PasswordInput value={form.password} onChange={set('password')} placeholder={mode === 'login' ? 'Tu contraseña' : 'Mínimo 8 caracteres'} autoComplete={mode === 'login' ? 'current-password' : 'new-password'}/></label>
          {mode === 'register' && <label className="form-field"><span>Confirmar contraseña<em>*</em></span><PasswordInput value={form.confirm} onChange={set('confirm')} placeholder="Repite la contraseña" autoComplete="new-password"/></label>}
        </div>

        {error && <div className="form-error" role="alert"><CircleAlert size={17}/>{error}</div>}

        <button className="btn btn-primary auth-submit" type="submit" disabled={busy}>
          {busy ? <Loader2 size={18} className="spin"/> : <ArrowRight size={18}/>}
          {mode === 'login' ? 'Entrar' : 'Registrarme'}
        </button>

        {mode === 'register' && <p className="auth-note">Las cuentas nuevas se crean con rol <strong>Participante</strong>. Un administrador puede cambiar tu rol desde el módulo de usuarios.</p>}
        {mode === 'login' && API_MODE === 'mock' && <div className="form-hint auth-demo"><KeyRound size={16}/><span>Demo: <button type="button" className="link-button" onClick={fillAdmin}>usar la cuenta de administrador</button> ({DEMO_ADMIN.correo} / {DEMO_ADMIN.password})</span></div>}
      </form>
    </main>
  </div>
}
