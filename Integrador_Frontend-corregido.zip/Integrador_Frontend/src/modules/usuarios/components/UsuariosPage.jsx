import EntityPage from '../../core/components/crud/EntityPage.jsx'

export default function UsuariosPage() {
  return <EntityPage type="usuarios"/>
}
