package com.integrador.backend.repositorios;

import com.integrador.backend.modelos.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface IRepositorioUsuario extends JpaRepository<Usuario, UUID> {

    Optional<Usuario> findByCorreoIgnoreCase(String correo);

    boolean existsByCorreoIgnoreCaseAndIdNot(String correo, UUID id);

    boolean existsByCorreoIgnoreCase(String correo);

    // ¿Hay al menos un usuario con este rol y estado? (para crear el primer administrador)
    boolean existsByRolAndEstado(String rol, String estado);

    // Para no dejar el sistema sin administradores activos
    long countByRolAndEstadoAndIdNot(String rol, String estado, UUID id);
}
