import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { Check, X } from 'lucide-react'

const ToastContext = createContext(null)

export function ToastProvider({ children }) {
  const [toast, setToast] = useState('')

  useEffect(() => {
    if (!toast) return undefined
    const timeout = setTimeout(() => setToast(''), 4200)
    return () => clearTimeout(timeout)
  }, [toast])

  const notify = useCallback(message => setToast(message), [])
  const value = useMemo(() => ({ notify }), [notify])

  return <ToastContext.Provider value={value}>
    {children}
    {toast && <div className="toast" role="status"><span className="toast-icon"><Check size={17}/></span>{toast}<button aria-label="Cerrar notificación" onClick={() => setToast('')}><X size={16}/></button></div>}
  </ToastContext.Provider>
}

export const useToast = () => useContext(ToastContext)
