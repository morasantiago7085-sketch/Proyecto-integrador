package com.integrador.backend.modelos;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(
        name = "registros",
        uniqueConstraints = @UniqueConstraint(
                name = "uk_registro_usuario_reto",
                columnNames = {"id_usuario", "id_reto"}
        )
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Registro {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @JdbcTypeCode(SqlTypes.CHAR)
    @Column(name = "id", length = 36, nullable = false, updatable = false)
    private UUID id;

    // Si no viene en la petición, el servicio la llena con la fecha actual
    @Column(name = "fecha_registro", nullable = false)
    private LocalDate fechaRegistro;

    // Puede ser nulo: en la simulación ~20% de los registros no traen observación
    @Size(max = 500, message = "La observación no puede superar 500 caracteres")
    @Column(length = 500)
    private String observacion;

    // Valores que usa el frontend: "Pendiente", "Aprobado", "Rechazado"
    @NotBlank(message = "El estado es obligatorio")
    @Column(nullable = false)
    private String estado;

    @NotNull(message = "El usuario es obligatorio")
    @JdbcTypeCode(SqlTypes.CHAR)
    @Column(name = "id_usuario", length = 36, nullable = false)
    private UUID usuarioId;

    @NotNull(message = "El reto es obligatorio")
    @JdbcTypeCode(SqlTypes.CHAR)
    @Column(name = "id_reto", length = 36, nullable = false)
    private UUID retoId;
}
