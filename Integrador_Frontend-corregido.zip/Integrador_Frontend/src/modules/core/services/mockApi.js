// API simulada en el navegador (localStorage). Misma interfaz que httpApi.js.
// Se usa por defecto para que el proyecto funcione sin backend; ver VITE_API_MODE.
import { storage } from '../lib/storage.js'
import { SESSION_KEY } from '../lib/http.js'
import { makeId } from '../utils/ids.js'
import { can } from '../../auth/lib/permissions.js'
import { CARGO_VALUES } from '../../auth/lib/cargos.js'
import { buildSeed, seedPasswords } from './seed.js'

const DB_KEY = 'nexo.db.v2'
const CRED_KEY = 'nexo.credentials.v2'

const wait = (ms = 120) => new Promise(resolve => setTimeout(resolve, ms))
const clone = value => JSON.parse(JSON.stringify(value))

async function hash(password) {
  const text = `nexo::${password}`
  if (globalThis.crypto?.subtle) {
    const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text))
    return [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2, '0')).join('')
  }
  let h = 5381 // respaldo para contextos sin crypto.subtle (HTTP en red local)
  for (const char of text) h = ((h << 5) + h + char.charCodeAt(0)) | 0
  return `weak-${h}`
}

async function load() {
  let db = storage.get(DB_KEY)
  let credentials = storage.get(CRED_KEY)
  if (!db || !credentials) {
    db = buildSeed()
    credentials = {}
    for (const [id, password] of Object.entries(seedPasswords())) credentials[id] = await hash(password)
    storage.set(DB_KEY, db)
    storage.set(CRED_KEY, credentials)
  }
  // Migración: categorías guardadas antes de existir «areaResponsable».
  if (db.categorias.some(c => !c.areaResponsable)) {
    db.categorias = db.categorias.map(c => ({ ...c, areaResponsable: c.areaResponsable || 'Por asignar' }))
    storage.set(DB_KEY, db)
  }
  if (db.empresas.some(e => !e.ubicacion)) {
    db.empresas = db.empresas.map(e => ({ ...e, ubicacion: e.ubicacion || 'Sin especificar' }))
    storage.set(DB_KEY, db)
  }
  return { db, credentials }
}

const save = ({ db, credentials }) => {
  storage.set(DB_KEY, db)
  storage.set(CRED_KEY, credentials)
}

const fail = (message, status = 400) => Object.assign(new Error(message), { status })
const emailOk = value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)

// Claves foráneas: no se elimina un registro con dependientes.
const dependents = {
  empresas: [['retos', 'empresaId']],
  categorias: [['retos', 'categoriaId']],
  prioridades: [['retos', 'prioridadId'], ['empresas', 'prioridadId']],
  usuarios: [['registros', 'usuarioId']],
  retos: [['registros', 'retoId']],
}

function sessionUser(state) {
  const token = storage.get(SESSION_KEY)?.token ?? ''
  const id = token.startsWith('mock.') ? token.slice(5) : null
  return state.db.usuarios.find(user => user.id === id) ?? null
}

function requireCan(state, action, type) {
  const user = sessionUser(state)
  if (!user || user.estado !== 'Activo') throw fail('Tu sesión no es válida. Inicia sesión de nuevo.', 401)
  if (!can(user, action, type)) throw fail('No tienes permisos para realizar esta acción.', 403)
  return user
}

function validateUser(state, row, isEdit) {
  if (!emailOk(row.correo)) throw fail('Ingresa un correo electrónico válido.')
  if (state.db.usuarios.some(user => user.correo.toLowerCase() === row.correo.toLowerCase() && user.id !== row.id)) throw fail('Ese correo ya está registrado.', 409)
  if (!CARGO_VALUES.includes(row.cargo)) throw fail('Selecciona un cargo válido.')
  if (!isEdit && String(row.password ?? '').length < 8) throw fail('La contraseña debe tener al menos 8 caracteres.')
  if (row.password && String(row.password).length < 8) throw fail('La contraseña debe tener al menos 8 caracteres.')
}

function checkCategoria(state, row) {
  if (!String(row.areaResponsable ?? '').trim()) throw fail('Indica el área responsable de la categoría.')
  if (state.db.categorias.some(c => c.nombre.trim().toLowerCase() === String(row.nombre).trim().toLowerCase() && c.id !== row.id)) throw fail('Ya existe una categoría con ese nombre.', 409)
}

const publicUser = user => ({ ...user })

export const mockApi = {
  async getData() {
    await wait()
    const state = await load()
    if (!sessionUser(state)) throw fail('Tu sesión no es válida. Inicia sesión de nuevo.', 401)
    return clone(state.db)
  },

  async create(type, row) {
    await wait()
    const state = await load()
    requireCan(state, 'create', type)
    const { password, ...record } = row
    record.id = record.id || makeId()
    if (type === 'usuarios') {
      validateUser(state, row, false)
      state.credentials[record.id] = await hash(password)
    }
    if (type === 'categorias') checkCategoria(state, record)
    if (type === 'registros' && state.db.registros.some(r => r.usuarioId === record.usuarioId && r.retoId === record.retoId)) {
      throw fail('Este usuario ya está inscrito en ese reto.', 409)
    }
    state.db[type].unshift(record)
    save(state)
    return clone(record)
  },

  async update(type, id, row) {
    await wait()
    const state = await load()
    const actor = requireCan(state, 'update', type)
    const index = state.db[type].findIndex(item => item.id === id)
    if (index < 0) throw fail('El registro no existe.', 404)
    const { password, ...record } = row
    if (type === 'categorias') checkCategoria(state, { ...record, id })
    if (type === 'usuarios') {
      validateUser(state, { ...row, id }, true)
      const admins = state.db.usuarios.filter(u => u.rol === 'Administrador' && u.estado === 'Activo' && u.id !== id)
      if ((record.rol !== 'Administrador' || record.estado !== 'Activo') && admins.length === 0) throw fail('Debe existir al menos un administrador activo.', 409)
      if (id === actor.id && record.estado !== 'Activo') throw fail('No puedes desactivar tu propia cuenta.', 409)
      if (password) state.credentials[id] = await hash(password)
    }
    state.db[type][index] = { ...state.db[type][index], ...record, id }
    save(state)
    return clone(state.db[type][index])
  },

  async remove(type, id) {
    await wait()
    const state = await load()
    const actor = requireCan(state, 'delete', type)
    if (type === 'usuarios') {
      if (id === actor.id) throw fail('No puedes eliminar tu propia cuenta.', 409)
      const target = state.db.usuarios.find(u => u.id === id)
      const otherAdmins = state.db.usuarios.filter(u => u.rol === 'Administrador' && u.estado === 'Activo' && u.id !== id)
      if (target?.rol === 'Administrador' && otherAdmins.length === 0) throw fail('Debe existir al menos un administrador activo.', 409)
    }
    for (const [table, field] of dependents[type] ?? []) {
      if (state.db[table].some(row => row[field] === id)) throw fail(`No se puede eliminar: tiene ${table} relacionados.`, 409)
    }
    state.db[type] = state.db[type].filter(item => item.id !== id)
    delete state.credentials[id]
    save(state)
  },

  async login({ correo, password }) {
    await wait(250)
    const state = await load()
    const user = state.db.usuarios.find(item => item.correo.toLowerCase() === String(correo).trim().toLowerCase())
    if (!user || state.credentials[user.id] !== await hash(password)) throw fail('Correo o contraseña incorrectos.', 401)
    if (user.estado !== 'Activo') throw fail('Tu cuenta está inactiva. Contacta a un administrador.', 403)
    return { token: `mock.${user.id}`, user: publicUser(user) }
  },

  async register({ nombre, correo, cargo, password }) {
    await wait(250)
    const state = await load()
    const row = { id: makeId(), nombre: String(nombre).trim(), correo: String(correo).trim(), cargo, rol: 'Participante', estado: 'Activo', password }
    if (!row.nombre) throw fail('Ingresa tu nombre completo.')
    validateUser(state, row, false)
    const { password: raw, ...user } = row
    state.credentials[user.id] = await hash(raw)
    state.db.usuarios.unshift(user)
    save(state)
    return { token: `mock.${user.id}`, user: publicUser(user) }
  },

  async me() {
    await wait(60)
    const user = sessionUser(await load())
    if (!user || user.estado !== 'Activo') throw fail('Sesión no válida.', 401)
    return publicUser(user)
  },
}
