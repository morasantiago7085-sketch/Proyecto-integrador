import { httpApi } from './httpApi.js'
import { mockApi } from './mockApi.js'

// VITE_API_MODE=http usa el backend real; por defecto se usa la API simulada del navegador.
export const API_MODE = import.meta.env.VITE_API_MODE === 'http' ? 'http' : 'mock'
export const api = API_MODE === 'http' ? httpApi : mockApi
