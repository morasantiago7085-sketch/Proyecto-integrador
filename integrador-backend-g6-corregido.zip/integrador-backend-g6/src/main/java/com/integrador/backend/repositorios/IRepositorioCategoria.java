package com.integrador.backend.repositorios;

import com.integrador.backend.modelos.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface IRepositorioCategoria extends JpaRepository<Categoria, UUID> {
}
