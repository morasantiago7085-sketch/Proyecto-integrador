import { api } from '../../core/services/api.js'
import { storage } from '../../core/lib/storage.js'
import { SESSION_KEY } from '../../core/lib/http.js'

const persist = ({ token, user }) => {
  storage.set(SESSION_KEY, { token })
  return user
}

export const authService = {
  login: async credentials => persist(await api.login(credentials)),
  register: async details => persist(await api.register(details)),
  restore: async () => (storage.get(SESSION_KEY)?.token ? api.me() : null),
  logout: () => storage.remove(SESSION_KEY),
}
