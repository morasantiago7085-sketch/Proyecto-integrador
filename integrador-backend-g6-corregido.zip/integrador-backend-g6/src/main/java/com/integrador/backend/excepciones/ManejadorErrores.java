package com.integrador.backend.excepciones;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Convierte los errores más comunes en respuestas con el mismo formato:
 * { estado, mensaje, errores? }. El frontend muestra el campo "mensaje".
 * datos inválidos -> 400, valor duplicado o restricción de la BD -> 409,
 * y los ResponseStatusException de los servicios (409, 401, 403...) con su propio texto.
 */
@RestControllerAdvice
public class ManejadorErrores {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> datosInvalidos(MethodArgumentNotValidException ex) {
        Map<String, String> errores = new LinkedHashMap<>();
        ex.getBindingResult().getFieldErrors()
                .forEach(e -> errores.putIfAbsent(e.getField(), e.getDefaultMessage()));

        // Como mensaje principal va el primer error concreto (ej. "El NIT es obligatorio")
        String mensaje = errores.values().stream().findFirst().orElse("Hay datos inválidos en la petición");
        Map<String, Object> cuerpo = cuerpo(HttpStatus.BAD_REQUEST, mensaje);
        cuerpo.put("errores", errores);
        return ResponseEntity.badRequest().body(cuerpo);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, Object>> cuerpoIlegible(HttpMessageNotReadableException ex) {
        return ResponseEntity.badRequest().body(cuerpo(HttpStatus.BAD_REQUEST,
                "El formato de los datos enviados no es válido (revisa fechas e identificadores)"));
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<Map<String, Object>> conflictoDeDatos(DataIntegrityViolationException ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(cuerpo(HttpStatus.CONFLICT,
                "Ya existe un registro con ese valor único (por ejemplo nombre, NIT o correo) "
                        + "o se incumple una restricción de la base de datos"));
    }

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<Map<String, Object>> conEstado(ResponseStatusException ex) {
        HttpStatus estado = HttpStatus.resolve(ex.getStatusCode().value());
        String mensaje = ex.getReason() != null ? ex.getReason() : "Error en la petición";
        return ResponseEntity.status(ex.getStatusCode())
                .body(cuerpo(estado != null ? estado : HttpStatus.BAD_REQUEST, mensaje));
    }

    private Map<String, Object> cuerpo(HttpStatus estado, String mensaje) {
        Map<String, Object> cuerpo = new LinkedHashMap<>();
        cuerpo.put("estado", estado.value());
        cuerpo.put("mensaje", mensaje);
        return cuerpo;
    }
}
