package com.integrador.backend.configuracion;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * Solo se usa la librería de cifrado (spring-security-crypto), NO Spring Security completo,
 * para no bloquear los endpoints. Las contraseñas se guardan con BCrypt.
 */
@Configuration
public class ConfiguracionContrasenas {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
