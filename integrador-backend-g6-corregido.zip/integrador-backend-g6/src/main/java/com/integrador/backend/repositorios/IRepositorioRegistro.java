package com.integrador.backend.repositorios;

import com.integrador.backend.modelos.Registro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface IRepositorioRegistro extends JpaRepository<Registro, UUID> {

    // ¿Ya existe una inscripción de este usuario en este reto?
    boolean existsByUsuarioIdAndRetoId(UUID usuarioId, UUID retoId);

    // Igual, pero ignorando el propio registro (para cuando se actualiza)
    boolean existsByUsuarioIdAndRetoIdAndIdNot(UUID usuarioId, UUID retoId, UUID id);

    // Para impedir borrar usuarios o retos que tienen inscripciones
    boolean existsByUsuarioId(UUID usuarioId);

    boolean existsByRetoId(UUID retoId);
}
