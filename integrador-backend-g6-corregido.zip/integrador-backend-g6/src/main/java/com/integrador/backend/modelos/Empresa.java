package com.integrador.backend.modelos;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.util.UUID;

@Entity
@Table(name = "empresas")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Empresa {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @JdbcTypeCode(SqlTypes.CHAR)
    @Column(name = "id", length = 36, nullable = false, unique = true, updatable = false)
    private UUID id;

    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 150, message = "El nombre no puede superar 150 caracteres")
    @Column(length = 150, nullable = false)
    private String nombre;

    @NotBlank(message = "El NIT es obligatorio")
    @Size(max = 20, message = "El NIT no puede superar 20 caracteres")
    @Column(length = 20, nullable = false, unique = true)
    private String nit;

    @Column(length = 80)
    private String sector;

    @Column(length = 100)
    private String contacto;

    @Email(message = "El correo no tiene un formato válido")
    @Size(max = 120, message = "El correo no puede superar 120 caracteres")
    @Column(length = 120)
    private String correo;

    @Column(length = 25)
    private String telefono;

    @Size(max = 150, message = "La ubicación no puede superar 150 caracteres")
    @Column(length = 150)
    private String ubicacion;

    @JdbcTypeCode(SqlTypes.CHAR)
    @Column(name = "prioridad_id", length = 36)
    private UUID prioridadId;

    @Column(nullable = false)
    @ColumnDefault("true")
    private Boolean activa = true;
}
