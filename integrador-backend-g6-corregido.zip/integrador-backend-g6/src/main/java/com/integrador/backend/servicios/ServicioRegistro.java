package com.integrador.backend.servicios;

import com.integrador.backend.modelos.Registro;
import com.integrador.backend.repositorios.IRepositorioRegistro;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ServicioRegistro {

    private static final String MENSAJE_CONFLICTO = "El usuario ya está inscrito en este reto";

    private final IRepositorioRegistro repositorio;

    public List<Registro> listar() {
        return repositorio.findAll();
    }

    public Optional<Registro> buscarPorId(UUID id) {
        return repositorio.findById(id);
    }

    public Registro guardar(Registro registro) {
        registro.setId(null); // el id lo genera el servidor
        // Un usuario no puede inscribirse dos veces en el mismo reto -> 409
        if (repositorio.existsByUsuarioIdAndRetoId(registro.getUsuarioId(), registro.getRetoId())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, MENSAJE_CONFLICTO);
        }
        if (registro.getFechaRegistro() == null) {
            registro.setFechaRegistro(LocalDate.now());
        }
        return repositorio.save(registro);
    }

    public Optional<Registro> actualizar(UUID id, Registro datos) {
        return repositorio.findById(id).map(existente -> {
            if (repositorio.existsByUsuarioIdAndRetoIdAndIdNot(datos.getUsuarioId(), datos.getRetoId(), id)) {
                throw new ResponseStatusException(HttpStatus.CONFLICT, MENSAJE_CONFLICTO);
            }
            if (datos.getFechaRegistro() != null) {
                existente.setFechaRegistro(datos.getFechaRegistro());
            }
            existente.setObservacion(datos.getObservacion());
            existente.setEstado(datos.getEstado());
            existente.setUsuarioId(datos.getUsuarioId());
            existente.setRetoId(datos.getRetoId());
            return repositorio.save(existente);
        });
    }

    public boolean eliminar(UUID id) {
        if (!repositorio.existsById(id)) {
            return false;
        }
        repositorio.deleteById(id);
        return true;
    }
}
