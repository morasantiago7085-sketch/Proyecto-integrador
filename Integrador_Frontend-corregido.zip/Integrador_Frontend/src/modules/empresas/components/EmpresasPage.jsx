import EntityPage from '../../core/components/crud/EntityPage.jsx'

export default function EmpresasPage() {
  return <EntityPage type="empresas"/>
}
