import { ArrowUpRight, CalendarDays, Pencil, Target } from 'lucide-react'
import { formatDate, getName } from '../../core/utils/formatters.js'
import { StatusBadge } from '../../core/design-system/UI.jsx'

export default function ChallengeCard({ reto, data, onView, onEdit, index = 0 }) {
  const empresa = getName(data, 'empresas', reto.empresaId)
  const prioridad = getName(data, 'prioridades', reto.prioridadId)
  const categoria = getName(data, 'categorias', reto.categoriaId)
  return <article className="challenge-card">
    <div className="challenge-card-head"><span className={`challenge-icon challenge-tone-${index % 5}`}><Target size={21}/></span><StatusBadge value={reto.estado}/></div>
    <div className="challenge-company">{empresa}</div>
    <button className="challenge-title" onClick={() => onView(reto)}>{reto.nombre}</button>
    <p>{reto.descripcion}</p>
    <div className="challenge-tags"><span>{categoria}</span><StatusBadge priority value={prioridad}/></div>
    <div className="challenge-card-footer"><span><CalendarDays size={15}/> {formatDate(reto.fechaInicio)} → {formatDate(reto.fechaFin)}</span><span className="card-actions">{onEdit && <button className="card-edit" onClick={() => onEdit('retos', reto)} aria-label={`Editar ${reto.nombre}`} title="Editar"><Pencil size={15}/> Editar</button>}<button onClick={() => onView(reto)} aria-label={`Ver detalle de ${reto.nombre}`} title="Ver detalle"><ArrowUpRight size={20}/></button></span></div>
  </article>
}
