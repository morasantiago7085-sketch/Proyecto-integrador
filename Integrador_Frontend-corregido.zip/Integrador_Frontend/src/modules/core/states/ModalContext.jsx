import { createContext, useCallback, useContext, useMemo, useState } from 'react'
import { FormModal, DeleteModal } from '../components/crud/EntityModals.jsx'
import { useData } from './DataContext.jsx'

const ModalContext = createContext(null)

// `renderDetail` permite que un módulo (p. ej. retos) aporte su propio modal de detalle.
export function ModalProvider({ children, renderDetail }) {
  const { data, saveRecord, removeRecord } = useData()
  const [modal, setModal] = useState(null)
  const close = useCallback(() => setModal(null), [])

  const actions = useMemo(() => ({
    openCreate: (type, initialValues) => setModal({ kind: 'form', type, initialValues }),
    openEdit: (type, item) => setModal({ kind: 'form', type, item }),
    openDelete: (type, item) => setModal({ kind: 'delete', type, item }),
    openView: item => setModal({ kind: 'detail', itemId: item.id }),
  }), [])

  const detailItem = modal?.kind === 'detail' ? data.retos.find(reto => reto.id === modal.itemId) : null

  return <ModalContext.Provider value={actions}>
    {children}
    {modal?.kind === 'form' && <FormModal key={`${modal.type}-${modal.item?.id || 'new'}`} type={modal.type} item={modal.item} initialValues={modal.initialValues} data={data} onClose={close}
      onSave={async (...args) => { if (await saveRecord(...args)) close() }}/>}
    {modal?.kind === 'delete' && <DeleteModal type={modal.type} item={modal.item} data={data} onClose={close}
      onConfirm={async (type, id) => { if (await removeRecord(type, id)) close() }}/>}
    {detailItem && renderDetail?.({ item: detailItem, data, onClose: close, ...actions })}
  </ModalContext.Provider>
}

export const useModals = () => useContext(ModalContext)
