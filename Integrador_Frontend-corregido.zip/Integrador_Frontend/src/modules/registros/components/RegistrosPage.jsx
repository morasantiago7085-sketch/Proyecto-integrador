import EntityPage from '../../core/components/crud/EntityPage.jsx'

export default function RegistrosPage() {
  return <EntityPage type="registros"/>
}
