import {
  ArrowUpRight, BookOpen, Building2, ChevronDown, ClipboardList, Flag,
  Layers3, LayoutDashboard, LogOut, ShieldCheck, Sparkles, Tags, Target, UsersRound, X,
} from 'lucide-react'
import { navItems } from '../../lib/registry.js'
import { Avatar, Logo } from '../../design-system/UI.jsx'
import { useAuth } from '../../../auth/states/AuthContext.jsx'
import { useData } from '../../states/DataContext.jsx'
import { can } from '../../../auth/lib/permissions.js'

const icons = { LayoutDashboard, Target, Building2, Tags, Flag, UsersRound, ClipboardList }

export default function Sidebar({ active, onNavigate, open, onClose }) {
  const { user, logout } = useAuth()
  const { data } = useData()
  const visible = navItems.filter(nav => nav.id === 'dashboard' || can(user, 'read', nav.id))
  const go = id => { onNavigate(id); onClose() }

  return <>
    {open && <div className="mobile-backdrop" onClick={onClose}/>}
    <aside className={`sidebar ${open ? 'open' : ''}`}>
      <div className="sidebar-top"><Logo/><button className="icon-only sidebar-close" onClick={onClose} aria-label="Cerrar menú"><X size={19}/></button></div>
      <div className="sidebar-workspace"><span className="workspace-icon"><Layers3 size={19}/></span><div><strong>Espacio de trabajo</strong><small>Proyecto integrador III</small></div><ChevronDown size={15}/></div>
      <div className="menu-caption">MENÚ PRINCIPAL</div>
      <nav aria-label="Navegación principal" className="nav-items">
        {visible.map(nav => {
          const Icon = icons[nav.icon]
          return <button key={nav.id} className={`nav-item ${active === nav.id ? 'active' : ''}`} onClick={() => go(nav.id)}>
            <Icon size={19} strokeWidth={1.95}/><span>{nav.label}</span>
            {nav.id === 'registros' && <span className="nav-count">{data.registros.length}</span>}
            {nav.adminZone && <ShieldCheck size={14} className="nav-admin"/>}
          </button>
        })}
      </nav>
      <div className="sidebar-lower">
        <div className="menu-caption">TU ESPACIO</div>
        <button className={`nav-item ${active === 'acerca' ? 'active' : ''}`} onClick={() => go('acerca')}><BookOpen size={19}/><span>Sobre el proyecto</span></button>
        <div className="sidebar-promo">
          <span className="sparkle-surface"><Sparkles size={22}/></span>
          <strong>Las grandes ideas empiezan con un reto.</strong>
          <p>Conecta empresas con soluciones que generan impacto.</p>
          <button onClick={() => go('retos')}>Explorar retos <ArrowUpRight size={15}/></button>
        </div>
        <div className="sidebar-profile">
          <Avatar name={user.nombre} index={4}/>
          <span><strong>{user.nombre}</strong><small>{user.cargo} · {user.rol}</small></span>
          <button className="icon-only profile-options" onClick={logout} title="Cerrar sesión" aria-label="Cerrar sesión"><LogOut size={18}/></button>
        </div>
      </div>
    </aside>
  </>
}
