import EntityPage from '../../core/components/crud/EntityPage.jsx'

export default function CategoriasPage() {
  return <EntityPage type="categorias"/>
}
