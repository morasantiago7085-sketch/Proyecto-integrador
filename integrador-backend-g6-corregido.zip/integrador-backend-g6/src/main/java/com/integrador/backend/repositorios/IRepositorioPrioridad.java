package com.integrador.backend.repositorios;

import com.integrador.backend.modelos.Prioridad;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface IRepositorioPrioridad extends JpaRepository<Prioridad, UUID> {
}