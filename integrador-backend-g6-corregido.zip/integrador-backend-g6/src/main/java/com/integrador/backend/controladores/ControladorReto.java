package com.integrador.backend.controladores;

import com.integrador.backend.modelos.Reto;
import com.integrador.backend.servicios.ServicioReto;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/retos")
@RequiredArgsConstructor
public class ControladorReto {

    private final ServicioReto servicio;

    @GetMapping
    public List<Reto> listar() {
        return servicio.listar();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Reto> buscarPorId(@PathVariable UUID id) {
        return servicio.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Reto> crear(@Valid @RequestBody Reto reto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(servicio.guardar(reto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Reto> actualizar(@PathVariable UUID id, @Valid @RequestBody Reto reto) {
        return servicio.actualizar(id, reto)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable UUID id) {
        return servicio.eliminar(id)
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }
}
