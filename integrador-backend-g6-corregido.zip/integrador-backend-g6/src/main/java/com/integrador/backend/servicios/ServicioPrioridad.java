package com.integrador.backend.servicios;

import com.integrador.backend.modelos.Prioridad;
import com.integrador.backend.repositorios.IRepositorioEmpresa;
import com.integrador.backend.repositorios.IRepositorioPrioridad;
import com.integrador.backend.repositorios.IRepositorioReto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ServicioPrioridad {

    private final IRepositorioPrioridad repositorio;
    private final IRepositorioReto repositorioReto;
    private final IRepositorioEmpresa repositorioEmpresa;

    public List<Prioridad> listar() {
        return repositorio.findAll();
    }

    public Optional<Prioridad> buscarPorId(UUID id) {
        return repositorio.findById(id);
    }

    public Prioridad guardar(Prioridad prioridad) {
        prioridad.setId(null); // el id lo genera el servidor, aunque el frontend mande uno
        return repositorio.save(prioridad);
    }

    public Optional<Prioridad> actualizar(UUID id, Prioridad datos) {
        return repositorio.findById(id).map(existente -> {
            existente.setNombre(datos.getNombre());
            existente.setNivel(datos.getNivel());
            return repositorio.save(existente);
        });
    }

    public boolean eliminar(UUID id) {
        if (!repositorio.existsById(id)) {
            return false;
        }
        if (repositorioReto.existsByPrioridadId(id) || repositorioEmpresa.existsByPrioridadId(id)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "No se puede eliminar: tiene retos o empresas relacionados");
        }
        repositorio.deleteById(id);
        return true;
    }
}
