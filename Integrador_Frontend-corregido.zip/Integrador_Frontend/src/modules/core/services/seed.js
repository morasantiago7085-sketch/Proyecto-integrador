import { todayString } from '../utils/formatters.js'

const uuid = n => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`

const daysFromToday = offset => {
  const date = new Date()
  date.setDate(date.getDate() + offset)
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
}

export const DEMO_ADMIN = { correo: 'admin@nexo.co', password: 'Admin123*' }
export const DEMO_PASSWORD = 'Nexo2026*'

export function buildSeed() {
  const prioridades = [
    { id: uuid(1), nombre: 'Alta', nivel: 3 },
    { id: uuid(2), nombre: 'Media', nivel: 2 },
    { id: uuid(3), nombre: 'Baja', nivel: 1 },
  ]
  const categorias = [
    { id: uuid(11), nombre: 'Tecnología', descripcion: 'Soluciones de software, datos e infraestructura.', areaResponsable: 'Innovación y TI' },
    { id: uuid(12), nombre: 'Sostenibilidad', descripcion: 'Iniciativas ambientales y de economía circular.', areaResponsable: 'Gestión Ambiental' },
    { id: uuid(13), nombre: 'Logística', descripcion: 'Cadena de suministro, transporte y distribución.', areaResponsable: 'Operaciones' },
    { id: uuid(14), nombre: 'Educación', descripcion: 'Formación, capacitación y gestión del conocimiento.', areaResponsable: 'Talento Humano' },
    { id: uuid(15), nombre: 'Salud', descripcion: 'Servicios, bienestar y tecnología para la salud.', areaResponsable: 'Bienestar y Salud' },
  ]
  const empresas = [
    { id: uuid(21), nombre: 'Innovación del Norte SAS', nit: '900123456-7', sector: 'Tecnología', contacto: 'Laura Mejía', correo: 'contacto@innorte.example', telefono: '3001234567', ubicacion: 'Medellín, Antioquia', prioridadId: uuid(1), activa: true },
    { id: uuid(22), nombre: 'EcoVerde Colombia', nit: '901234567-8', sector: 'Sostenibilidad', contacto: 'Andrés Rojas', correo: 'hola@ecoverde.example', telefono: '3012345678', ubicacion: 'Bogotá D.C.', prioridadId: uuid(2), activa: true },
    { id: uuid(23), nombre: 'RutaExpress Logística', nit: '902345678-9', sector: 'Logística', contacto: 'Camila Duarte', correo: 'info@rutaexpress.example', telefono: '3023456789', ubicacion: 'Cali, Valle del Cauca', prioridadId: uuid(1), activa: true },
    { id: uuid(24), nombre: 'Aula Futura', nit: '903456789-0', sector: 'Educación', contacto: 'Sergio Pardo', correo: 'equipo@aulafutura.example', telefono: '3034567890', ubicacion: 'Barranquilla, Atlántico', prioridadId: uuid(3), activa: true },
    { id: uuid(25), nombre: 'VidaPlena Salud', nit: '904567890-1', sector: 'Salud', contacto: 'Paula Herrera', correo: 'alianzas@vidaplena.example', telefono: '3045678901', ubicacion: 'Bucaramanga, Santander', prioridadId: uuid(2), activa: false },
  ]
  const retos = [
    { id: uuid(31), nombre: 'Automatizar la facturación electrónica', descripcion: 'Integrar un flujo que genere y valide facturas electrónicas sin intervención manual.', empresaId: uuid(21), categoriaId: uuid(11), prioridadId: uuid(1), estado: 'Abierto', fechaInicio: daysFromToday(-20), fechaFin: daysFromToday(25), eventos: [{ id: uuid(61), nombre: 'Reunión de lanzamiento', fecha: daysFromToday(-18) }, { id: uuid(62), nombre: 'Entrega de propuestas', fecha: daysFromToday(15) }] },
    { id: uuid(32), nombre: 'Panel de huella de carbono', descripcion: 'Visualizar en tiempo real las emisiones de la operación y proponer metas de reducción.', empresaId: uuid(22), categoriaId: uuid(12), prioridadId: uuid(2), estado: 'Abierto', fechaInicio: daysFromToday(-10), fechaFin: daysFromToday(40) },
    { id: uuid(33), nombre: 'Optimizar rutas de última milla', descripcion: 'Reducir tiempos y costos de entrega en zonas urbanas con alta congestión.', empresaId: uuid(23), categoriaId: uuid(13), prioridadId: uuid(1), estado: 'Abierto', fechaInicio: daysFromToday(-5), fechaFin: daysFromToday(30) },
    { id: uuid(34), nombre: 'Plataforma de microaprendizaje', descripcion: 'Diseñar una experiencia móvil de lecciones cortas para capacitación interna.', empresaId: uuid(24), categoriaId: uuid(14), prioridadId: uuid(3), estado: 'En revisión', fechaInicio: daysFromToday(-45), fechaFin: daysFromToday(5) },
    { id: uuid(35), nombre: 'Agenda inteligente de citas', descripcion: 'Disminuir inasistencias con recordatorios y reprogramación automática.', empresaId: uuid(25), categoriaId: uuid(15), prioridadId: uuid(2), estado: 'Cerrado', fechaInicio: daysFromToday(-90), fechaFin: daysFromToday(-30) },
    { id: uuid(36), nombre: 'Monitoreo de inventario con IoT', descripcion: 'Detectar faltantes y excesos de bodega con sensores y alertas tempranas.', empresaId: uuid(23), categoriaId: uuid(11), prioridadId: uuid(2), estado: 'Abierto', fechaInicio: daysFromToday(-2), fechaFin: daysFromToday(60) },
  ]
  const usuarios = [
    { id: uuid(41), nombre: 'Administrador Nexo', correo: DEMO_ADMIN.correo, cargo: 'Desarrollador Full Stack', rol: 'Administrador', estado: 'Activo' },
    { id: uuid(42), nombre: 'Valentina Ortiz', correo: 'valentina@nexo.example', cargo: 'Desarrollador Frontend', rol: 'Evaluador', estado: 'Activo' },
    { id: uuid(43), nombre: 'Mateo Cárdenas', correo: 'mateo@nexo.example', cargo: 'Desarrollador Backend', rol: 'Participante', estado: 'Activo' },
    { id: uuid(44), nombre: 'Daniela Ríos', correo: 'daniela@nexo.example', cargo: 'Ingeniero DevOps', rol: 'Participante', estado: 'Activo' },
    { id: uuid(45), nombre: 'Julián Salcedo', correo: 'julian@nexo.example', cargo: 'Especialista en QA', rol: 'Participante', estado: 'Inactivo' },
  ]
  const registros = [
    { id: uuid(51), usuarioId: uuid(43), retoId: uuid(31), fechaRegistro: daysFromToday(-1), estado: 'Aprobado', observacion: 'Experiencia previa en integraciones.' },
    { id: uuid(52), usuarioId: uuid(44), retoId: uuid(33), fechaRegistro: daysFromToday(-2), estado: 'Pendiente', observacion: '' },
    { id: uuid(53), usuarioId: uuid(42), retoId: uuid(32), fechaRegistro: daysFromToday(-3), estado: 'Aprobado', observacion: 'Interesada en el panel de visualización.' },
    { id: uuid(54), usuarioId: uuid(45), retoId: uuid(34), fechaRegistro: daysFromToday(-5), estado: 'Rechazado', observacion: 'Cuenta inactiva.' },
    { id: uuid(55), usuarioId: uuid(43), retoId: uuid(36), fechaRegistro: todayString(), estado: 'Pendiente', observacion: '' },
  ]
  return { empresas, retos, categorias, prioridades, usuarios, registros }
}

// Credenciales de las cuentas de demostración (el administrador usa DEMO_ADMIN).
export const seedPasswords = () => ({
  [uuid(41)]: DEMO_ADMIN.password,
  [uuid(42)]: DEMO_PASSWORD,
  [uuid(43)]: DEMO_PASSWORD,
  [uuid(44)]: DEMO_PASSWORD,
  [uuid(45)]: DEMO_PASSWORD,
})
