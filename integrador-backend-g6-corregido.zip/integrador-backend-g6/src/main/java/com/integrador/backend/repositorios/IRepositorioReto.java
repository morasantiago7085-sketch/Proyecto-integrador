package com.integrador.backend.repositorios;

import com.integrador.backend.modelos.Reto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface IRepositorioReto extends JpaRepository<Reto, UUID> {

    boolean existsByEmpresaId(UUID empresaId);

    boolean existsByCategoriaId(UUID categoriaId);

    boolean existsByPrioridadId(UUID prioridadId);
}
