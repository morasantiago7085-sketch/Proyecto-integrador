import { Component } from 'react'
import { Loader2 } from 'lucide-react'
import { AuthProvider, useAuth } from './modules/auth/states/AuthContext.jsx'
import { ToastProvider } from './modules/core/states/ToastContext.jsx'
import { UIProvider } from './modules/core/states/UIContext.jsx'
import { DataProvider, useData } from './modules/core/states/DataContext.jsx'
import { ModalProvider } from './modules/core/states/ModalContext.jsx'
import { useHashRoute } from './modules/core/hooks/useHashRoute.js'
import { can } from './modules/auth/lib/permissions.js'
import AuthPage from './modules/auth/components/AuthPage.jsx'
import AppShell from './modules/core/components/layout/AppShell.jsx'
import Dashboard from './modules/dashboard/components/Dashboard.jsx'
import AboutPage from './modules/about/components/AboutPage.jsx'
import RetosPage from './modules/retos/components/RetosPage.jsx'
import ChallengeDetailModal from './modules/retos/components/ChallengeDetailModal.jsx'
import EmpresasPage from './modules/empresas/components/EmpresasPage.jsx'
import CategoriasPage from './modules/categorias/components/CategoriasPage.jsx'
import PrioridadesPage from './modules/prioridades/components/PrioridadesPage.jsx'
import RegistrosPage from './modules/registros/components/RegistrosPage.jsx'
import UsuariosPage from './modules/usuarios/components/UsuariosPage.jsx'

// Páginas disponibles: `entity` indica el permiso de lectura requerido.
const pages = {
  dashboard: { Component: Dashboard },
  acerca: { Component: AboutPage },
  retos: { Component: RetosPage, entity: 'retos' },
  empresas: { Component: EmpresasPage, entity: 'empresas' },
  categorias: { Component: CategoriasPage, entity: 'categorias' },
  prioridades: { Component: PrioridadesPage, entity: 'prioridades' },
  registros: { Component: RegistrosPage, entity: 'registros' },
  usuarios: { Component: UsuariosPage, entity: 'usuarios' },
}

const renderDetail = props => <ChallengeDetailModal {...props}/>

function Splash({ children }) {
  return <div className="auth-splash"><Loader2 className="spin" size={28}/>{children && <p>{children}</p>}</div>
}

function Workspace() {
  const { user } = useAuth()
  const { loading, error, reload } = useData()
  const [route, navigate] = useHashRoute()
  const page = pages[route] && (!pages[route].entity || can(user, 'read', pages[route].entity)) ? route : 'dashboard'
  const { Component } = pages[page]

  return <ModalProvider renderDetail={renderDetail}>
    <AppShell page={page} navigate={navigate}>
      {loading
        ? <div className="page"><div className="content-panel"><h2>Cargando información…</h2><p>Consultando los datos de la plataforma.</p></div></div>
        : error
          ? <div className="page"><div className="content-panel" role="alert"><h2>No se pudo conectar con el backend</h2><p>{error}</p><button className="btn btn-primary" onClick={reload}>Reintentar conexión</button></div></div>
          : <Component navigate={navigate}/>}
    </AppShell>
  </ModalProvider>
}

function Gate() {
  const { user, checking } = useAuth()
  if (checking) return <Splash>Verificando sesión…</Splash>
  if (!user) return <AuthPage/>
  return <DataProvider><Workspace/></DataProvider>
}

class ErrorBoundary extends Component {
  state = { failed: false }
  static getDerivedStateFromError() { return { failed: true } }
  render() {
    return this.state.failed
      ? <div className="auth-splash"><h2>Algo salió mal</h2><button className="btn btn-primary" onClick={() => window.location.reload()}>Recargar</button></div>
      : this.props.children
  }
}

export default function App() {
  return <ErrorBoundary>
    <ToastProvider>
      <AuthProvider>
        <UIProvider>
          <Gate/>
        </UIProvider>
      </AuthProvider>
    </ToastProvider>
  </ErrorBoundary>
}
