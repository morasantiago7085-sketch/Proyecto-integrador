package com.integrador.backend.repositorios;

import com.integrador.backend.modelos.Empresa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface IRepositorioEmpresa extends JpaRepository<Empresa, UUID> {

    boolean existsByPrioridadId(UUID prioridadId);
}
