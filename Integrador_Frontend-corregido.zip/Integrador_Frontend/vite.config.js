import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      // Backend Spring Boot (Java). Si usas el backend Node de clase, cambia 8080 por 3001.
      '/api': 'http://localhost:8080',
    },
  },
  // Prevent Vite from loading unrelated PostCSS/Tailwind configs
  // from parent folders (e.g. a postcss.config.mjs in Downloads).
  // This project uses plain CSS, not Tailwind CSS.
  css: {
    postcss: {
      plugins: [],
    },
  },
})
