package com.integrador.backend.controladores;

import com.integrador.backend.modelos.Registro;
import com.integrador.backend.servicios.ServicioRegistro;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/registros")
@RequiredArgsConstructor
public class ControladorRegistro {

    private final ServicioRegistro servicio;

    @GetMapping
    public List<Registro> listar() {
        return servicio.listar();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Registro> buscarPorId(@PathVariable UUID id) {
        return servicio.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Registro> crear(@Valid @RequestBody Registro registro) {
        return ResponseEntity.status(HttpStatus.CREATED).body(servicio.guardar(registro));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Registro> actualizar(@PathVariable UUID id, @Valid @RequestBody Registro registro) {
        return servicio.actualizar(id, registro)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable UUID id) {
        return servicio.eliminar(id)
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }
}
