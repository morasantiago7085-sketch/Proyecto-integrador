import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { api } from '../services/api.js'
import { entityConfig } from '../lib/registry.js'
import { useAuth } from '../../auth/states/AuthContext.jsx'
import { useToast } from './ToastContext.jsx'

const DataContext = createContext(null)

const emptyData = () => Object.fromEntries(Object.keys(entityConfig).map(type => [type, []]))

export function DataProvider({ children }) {
  const { user, logout, refresh } = useAuth()
  const { notify } = useToast()
  const [data, setData] = useState(emptyData)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [reloadKey, setReloadKey] = useState(0)

  useEffect(() => {
    let active = true
    setLoading(true)
    api.getData()
      .then(result => { if (active) { setData({ ...emptyData(), ...result }); setError('') } })
      .catch(err => {
        if (!active) return
        if (err.status === 401) logout()
        else setError(err.message)
      })
      .finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [reloadKey, user?.id, logout])

  const reload = useCallback(() => setReloadKey(key => key + 1), [])

  const saveRecord = useCallback(async (type, row, isEdit) => {
    try {
      const saved = isEdit ? await api.update(type, row.id, row) : await api.create(type, row)
      setData(prev => ({
        ...prev,
        [type]: isEdit ? prev[type].map(item => item.id === saved.id ? saved : item) : [saved, ...prev[type]],
      }))
      if (type === 'usuarios' && saved.id === user?.id) refresh()
      notify(isEdit ? 'Cambios guardados correctamente.' : 'Registro creado correctamente.')
      return true
    } catch (err) {
      notify(`No se pudo guardar: ${err.message}`)
      return false
    }
  }, [notify, refresh, user?.id])

  const removeRecord = useCallback(async (type, id) => {
    try {
      await api.remove(type, id)
      setData(prev => ({ ...prev, [type]: prev[type].filter(item => item.id !== id) }))
      notify('Registro eliminado correctamente.')
      return true
    } catch (err) {
      notify(`No se pudo eliminar: ${err.message}`)
      return false
    }
  }, [notify])

  const value = useMemo(() => ({ data, loading, error, reload, saveRecord, removeRecord }), [data, loading, error, reload, saveRecord, removeRecord])
  return <DataContext.Provider value={value}>{children}</DataContext.Provider>
}

export const useData = () => useContext(DataContext)
