import { useEffect, useMemo, useState } from 'react'
import {
  ArrowRight, CalendarDays, ChevronDown, ChevronRight, Download,
  Eye, LayoutGrid, List, Pencil, Plus, Search, SlidersHorizontal, Trash2, X,
} from 'lucide-react'
import { entityConfig } from '../../lib/registry.js'
import { cellValue, formatDate, getName, initials, normalizeText, todayString } from '../../utils/formatters.js'
import { Avatar, SectionHeading, StatusBadge } from '../../design-system/UI.jsx'
import { useData } from '../../states/DataContext.jsx'
import { useModals } from '../../states/ModalContext.jsx'
import { useToast } from '../../states/ToastContext.jsx'
import { useUI } from '../../states/UIContext.jsx'
import { useAuth } from '../../../auth/states/AuthContext.jsx'
import { can } from '../../../auth/lib/permissions.js'

const csvValue = value => `"${String(value ?? '').replace(/"/g, '""')}"`

/**
 * Página CRUD genérica (tabla, búsqueda, filtro, orden, CSV).
 * Un módulo puede aportar `renderCards` (vista de tarjetas) e `intro` (banner superior).
 */
export default function EntityPage({ type, renderCards, intro, viewable = false }) {
  const cfg = entityConfig[type]
  const { data } = useData()
  const { user } = useAuth()
  const { notify } = useToast()
  const { openCreate, openEdit, openDelete, openView } = useModals()
  const { searches, filters, setSearch, setFilter, viewMode, setViewMode } = useUI()
  const search = searches[type] ?? ''
  const filter = filters[type] ?? ''
  const [sort, setSort] = useState({ field: '', direction: 'asc' })
  const [visibleCount, setVisibleCount] = useState(10)

  const allowCreate = can(user, 'create', type)
  const allowUpdate = can(user, 'update', type)
  const allowDelete = can(user, 'delete', type)

  useEffect(() => {
    setSort({ field: '', direction: 'asc' })
    setVisibleCount(10)
  }, [type])

  const records = useMemo(() => {
    const term = normalizeText(search)
    const filtered = data[type].filter(item => {
      const values = [...Object.values(item), ...cfg.columns.map(col => cellValue(data, item, col))]
      const matchesSearch = values.some(value => normalizeText(value).includes(term))
      return matchesSearch && (!filter || item.estado === filter)
    })
    if (sort.field) {
      const col = cfg.columns.find(column => column.field === sort.field)
      filtered.sort((a, b) => String(cellValue(data, a, col) ?? '').localeCompare(String(cellValue(data, b, col) ?? ''), 'es', { numeric: true }) * (sort.direction === 'asc' ? 1 : -1))
    }
    return filtered
  }, [data, type, search, filter, sort, cfg])

  const suggestions = useMemo(() => [...new Set(data[type].map(item => item.nombre).filter(Boolean))], [data, type])
  const statuses = cfg.fields.find(field => field.name === 'estado')?.options ?? []
  const hasStatus = statuses.length > 0

  const exportCsv = () => {
    const rows = [cfg.columns.map(col => col.label), ...records.map(item => cfg.columns.map(col => cellValue(data, item, col)))]
    const contents = '﻿' + rows.map(row => row.map(csvValue).join(';')).join('\r\n')
    const url = URL.createObjectURL(new Blob([contents], { type: 'text/csv;charset=utf-8;' }))
    const link = document.createElement('a')
    link.href = url
    link.download = `nexo-${type}-${todayString()}.csv`
    document.body.appendChild(link)
    link.click()
    link.remove()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
    notify(`CSV de ${type} generado correctamente.`)
  }

  const toggleSort = field => setSort(previous => ({
    field,
    direction: previous.field === field && previous.direction === 'asc' ? 'desc' : 'asc',
  }))

  const primaryColumn = cfg.columns[0]?.field
  const renderCell = (item, col) => {
    const value = cellValue(data, item, col)
    if (col.type === 'boolean') return <StatusBadge value={value}/>
    if (col.count) return <span className="cell-count">{value}</span>
    if (col.field === 'estado' || col.field === 'rol') return <StatusBadge value={value}/>
    if (col.field === 'prioridadId') return value === '—' ? <span>—</span> : <StatusBadge priority value={value}/>
    if (col.type === 'date') return <span className="cell-date"><CalendarDays size={14}/>{formatDate(value)}</span>
    if (col.field === 'nombre' && type === 'usuarios') return <span className="cell-person"><Avatar name={value} size="small" index={data.usuarios.findIndex(row => row.id === item.id)}/><span><strong>{value}</strong>{item.id === user.id && <small className="you-tag"> (tú)</small>}</span></span>
    if (col.field === 'nombre' && type === 'empresas') return <span className="cell-company"><span className="company-monogram">{initials(value)}</span><strong>{value}</strong></span>
    if (col.field === primaryColumn) return <span className="cell-primary" title={String(value)}>{value}</span>
    if (col.field === 'correo') return <span className="cell-email" title={value}>{value}</span>
    if (col.field === 'descripcion' || col.field === 'observacion') return <span className="cell-truncate" title={value}>{value || '—'}</span>
    return <span title={String(value ?? '')}>{value || '—'}</span>
  }

  const showCards = renderCards && viewMode === 'cards'
  const rowLabel = item => item.nombre || getName(data, 'usuarios', item.usuarioId)

  return <div className="page entity-page">
    <div className="page-breadcrumb"><span>Espacio de trabajo</span><ChevronRight size={14}/><strong>{cfg.title}</strong></div>
    <SectionHeading eyebrow="GESTIÓN DE LA PLATAFORMA" title={cfg.title} subtitle={cfg.description}
      right={allowCreate && <button className="btn btn-primary" onClick={() => openCreate(type)}><Plus size={18}/> {cfg.newLabel ?? `Nuevo ${cfg.singular}`}</button>}/>
    {intro}
    <div className="management-card">
      <div className="table-title-row">
        <div className="table-title"><h3>Listado de {type}</h3><span className="count-badge">{records.length} {records.length === 1 ? 'registro' : 'registros'}</span></div>
        <div className="table-actions">
          {renderCards && <div className="view-toggle"><button onClick={() => setViewMode('cards')} title="Vista de tarjetas" className={viewMode === 'cards' ? 'selected' : ''}><LayoutGrid size={17}/></button><button onClick={() => setViewMode('table')} title="Vista de tabla" className={viewMode === 'table' ? 'selected' : ''}><List size={19}/></button></div>}
          <button className="btn btn-outline btn-small" onClick={exportCsv}><Download size={17}/> Exportar CSV</button>
        </div>
      </div>
      <div className="filters-row">
        <label className="search-field"><Search size={18}/><input list={`sugerencias-${type}`} autoComplete="off" aria-label={`Buscar ${type}`} placeholder={`Buscar ${cfg.singular}, nombre o palabra clave...`} value={search} onChange={event => setSearch(type, event.target.value)}/>{search && <button onClick={() => setSearch(type, '')} aria-label="Limpiar búsqueda"><X size={16}/></button>}<datalist id={`sugerencias-${type}`}>{suggestions.map(name => <option key={name} value={name}/>)}</datalist></label>
        {hasStatus && <label className="filter-select"><SlidersHorizontal size={17}/><select value={filter} onChange={event => setFilter(type, event.target.value)} aria-label="Filtrar por estado"><option value="">Todos los estados</option>{statuses.map(status => <option key={status}>{status}</option>)}</select><ChevronDown size={15}/></label>}
      </div>
      {showCards
        ? <div className="challenge-grid">{records.slice(0, visibleCount).map((item, index) => renderCards(item, index))}</div>
        : <div className="table-wrap"><table className="data-table">
          <thead><tr>{cfg.columns.map(col => <th key={col.field}><button onClick={() => toggleSort(col.field)} title={`Ordenar por ${col.label}`} className={sort.field === col.field ? 'sorted' : ''}>{col.label}{sort.field === col.field ? <span>{sort.direction === 'asc' ? '↑' : '↓'}</span> : null}</button></th>)}{(viewable || allowUpdate || allowDelete) && <th className="actions-header">Acciones</th>}</tr></thead>
          <tbody>{records.slice(0, visibleCount).map(item => <tr key={item.id} className={allowUpdate ? 'row-clickable' : ''} onDoubleClick={allowUpdate ? () => openEdit(type, item) : undefined} title={allowUpdate ? 'Doble clic para editar' : undefined}>
            {cfg.columns.map(col => <td key={col.field}>{renderCell(item, col)}</td>)}
            {(viewable || allowUpdate || allowDelete) && <td><div className="row-actions">
              {viewable && <button className="action-button" title="Ver detalle" aria-label={`Ver ${rowLabel(item)}`} onClick={() => openView(item)}><Eye size={17}/></button>}
              {allowUpdate && <button className="action-button" title="Editar" aria-label={`Editar ${rowLabel(item)}`} onClick={() => openEdit(type, item)}><Pencil size={16}/></button>}
              {allowDelete && <button className="action-button danger" title="Eliminar" aria-label={`Eliminar ${rowLabel(item)}`} onClick={() => openDelete(type, item)}><Trash2 size={16}/></button>}
            </div></td>}
          </tr>)}</tbody>
        </table></div>}
      {records.length === 0 && <div className="empty-state"><span><Search size={31}/></span><strong>No encontramos resultados</strong><p>Prueba con otro término, cambia los filtros{allowCreate ? ' o crea un nuevo registro' : ''}.</p><button className="btn btn-outline" onClick={() => { setSearch(type, ''); setFilter(type, '') }}>Limpiar filtros</button></div>}
      {records.length > 0 && <div className="table-footer"><span>Mostrando {Math.min(visibleCount, records.length)} de {records.length} resultados</span>{records.length > visibleCount ? <button className="text-action" onClick={() => setVisibleCount(count => count + 10)}>Mostrar más <ArrowRight size={16}/></button> : <span>Fin del listado</span>}</div>}
    </div>
  </div>
}
