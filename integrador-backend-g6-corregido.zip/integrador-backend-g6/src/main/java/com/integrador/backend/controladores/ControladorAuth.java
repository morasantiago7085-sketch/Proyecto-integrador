package com.integrador.backend.controladores;

import com.integrador.backend.modelos.Usuario;
import com.integrador.backend.servicios.ServicioToken;
import com.integrador.backend.servicios.ServicioUsuario;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;
import java.util.UUID;

/** Login, registro y sesión actual. El frontend espera { token, user }. */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class ControladorAuth {

    private final ServicioUsuario usuarios;
    private final ServicioToken tokens;

    public record Credenciales(
            @NotBlank(message = "El correo es obligatorio") String correo,
            @NotBlank(message = "La contraseña es obligatoria") String password) {
    }

    public record DatosRegistro(
            @NotBlank(message = "El nombre es obligatorio") @Size(max = 150) String nombre,
            @NotBlank(message = "El correo es obligatorio") @Email(message = "El correo no tiene un formato válido") String correo,
            @NotBlank(message = "El cargo es obligatorio") String cargo,
            @NotBlank(message = "La contraseña es obligatoria") String password) {
    }

    @PostMapping("/login")
    public Map<String, Object> login(@Valid @RequestBody Credenciales datos) {
        Usuario usuario = usuarios.buscarPorCorreo(datos.correo())
                .filter(u -> usuarios.contrasenaCoincide(u, datos.password()))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED,
                        "Correo o contraseña incorrectos"));
        if (!"Activo".equals(usuario.getEstado())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN,
                    "Tu cuenta está inactiva. Contacta a un administrador");
        }
        return respuesta(usuario);
    }

    @PostMapping("/register")
    public Map<String, Object> registrar(@Valid @RequestBody DatosRegistro datos) {
        Usuario creado = usuarios.registrar(datos.nombre(), datos.correo(), datos.cargo(), datos.password());
        return respuesta(creado);
    }

    @GetMapping("/me")
    public Usuario yo(@RequestHeader(value = "Authorization", required = false) String autorizacion) {
        if (autorizacion == null || !autorizacion.startsWith("Bearer ")) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Sesión no válida");
        }
        UUID id = tokens.validar(autorizacion.substring(7))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Sesión no válida"));
        return usuarios.buscarPorId(id)
                .filter(u -> "Activo".equals(u.getEstado()))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Sesión no válida"));
    }

    private Map<String, Object> respuesta(Usuario usuario) {
        return Map.of("token", tokens.generar(usuario.getId()), "user", usuario);
    }
}
