package com.integrador.backend.configuracion;

import com.integrador.backend.modelos.Prioridad;
import com.integrador.backend.modelos.Usuario;
import com.integrador.backend.repositorios.IRepositorioPrioridad;
import com.integrador.backend.repositorios.IRepositorioUsuario;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Datos mínimos para poder usar la aplicación desde cero. Solo se crean si hacen falta:
 * - Si no existe ningún administrador activo, crea admin@nexo.co / Admin123*
 *   (el registro público solo crea Participantes, que no pueden administrar los módulos).
 * - Si la tabla de prioridades está vacía, crea cuatro prioridades básicas.
 * Cambia la contraseña del administrador después de entrar.
 */
@Component
@RequiredArgsConstructor
public class DatosIniciales implements CommandLineRunner {

    private final IRepositorioUsuario usuarios;
    private final IRepositorioPrioridad prioridades;
    private final PasswordEncoder encoder;

    @Override
    public void run(String... args) {
        if (!usuarios.existsByRolAndEstado("Administrador", "Activo")
                && !usuarios.existsByCorreoIgnoreCase("admin@nexo.co")) {
            Usuario admin = new Usuario();
            admin.setNombre("Administrador Nexo");
            admin.setCorreo("admin@nexo.co");
            admin.setCargo("Desarrollador Full Stack");
            admin.setRol("Administrador");
            admin.setEstado("Activo");
            admin.setPassword(encoder.encode("Admin123*"));
            usuarios.save(admin);
        }

        if (prioridades.count() == 0) {
            String[] nombres = {"Urgente", "Alta", "Media", "Baja"};
            for (int i = 0; i < nombres.length; i++) {
                Prioridad prioridad = new Prioridad();
                prioridad.setNombre(nombres[i]);
                prioridad.setNivel(i + 1);
                prioridades.save(prioridad);
            }
        }
    }
}
